﻿using Cognex.VisionPro;
using Cognex.VisionPro.Display;
using Cognex.VisionPro.ImageFile;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WepApiHost;


namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        string[] filepaths;
        string csvFileName;
        string barcode;
        string data;
        private List<DataContent> dataList = new List<DataContent>();
        int totalReceive; 
        public Form1()
        {
            InitializeComponent();

            System.Threading.ThreadPool.GetMinThreads(out int a, out int b);

            System.Threading.ThreadPool.SetMinThreads(500, 500);
            dataGridView1.ColumnCount = 2;
            dataGridView1.Columns[0].Name = "檔案名稱";
            dataGridView1.Columns[1].Name = "檔案路徑";
            dataGridView1.CellClick += dataGridView1_CellClick;

            //dataGridViewDetail
            dataGridViewDetail.ColumnCount = 8;
            dataGridViewDetail.Columns[0].Name = "Pattern";
            dataGridViewDetail.Columns[1].Name = "RGB";
            dataGridViewDetail.Columns[2].Name = "Shiftx";
            dataGridViewDetail.Columns[3].Name = "Shifty";
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            await WepApiHost.WebApiFunctionTest.GetMessage("http://127.0.0.1:8888/", "echo?name=12345", 2000);
        }

        private async void Step1_Click(object sender, EventArgs e)
        {
            barcode = @"D:\維智\1.JPG";
            await WepApiHost.WebApiFunctionTest.GetMessage("http://127.0.0.1:8888/", $"echo?name={barcode}", 2000);
        }

        private async Task UploadFileWithHttpClientAsync(string[] filePaths, string url, string route)
        {

            var form = new MultipartFormDataContent();
            if (filePaths != null)
            {
                foreach (var str in filePaths)
                {
                    form.Add(new ByteArrayContent(File.ReadAllBytes(str)), Path.GetFileName(str));
                }
            }

            var httpClient = new HttpClient()
            {
                BaseAddress = new Uri(url)
            };

            var response = await httpClient.PostAsync("/" + route, form);
            response.EnsureSuccessStatusCode();

            var responseContent = await response.Content.ReadAsStringAsync();
        }

        private async Task UploadFileWithHttpClientAsync2(string[] filepaths, string url, string route)
        {
            var tasks = new List<Task>();

            foreach (string filepath in filepaths)
            {
                var form = new MultipartFormDataContent();
                form.Add(new ByteArrayContent(File.ReadAllBytes(filepath)), nameof(ByteArrayContent), Path.GetFileName(filepath));
                var httpClient = new HttpClient()
                {
                    BaseAddress = new Uri(url)
                };
                var response = await httpClient.PostAsync("/" + route, form);
                response.EnsureSuccessStatusCode();

                var responseContent = await response.Content.ReadAsStringAsync();
            }
            await Task.WhenAll(tasks);
        }


        private async void btnSendimage_Click(object sender, EventArgs e)
        {
            totalReceive = 0;
            dataGridView1.Rows.Clear();
            barcode = DateTime.Now.Ticks.ToString();
            csvFileName = @"..\ShiftResult_" + barcode + ".csv";
            InitializeCsv(csvFileName);
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Multiselect = true;
            dialog.Title = "請選擇檔案";
            dialog.Filter = "所有檔案(*.*)|*.*";

            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                string filename = dialog.FileName;
                filename = dialog.FileNames[0];
                filepaths = dialog.FileNames;
                txtTotalSend.Text = $"{dialog.FileNames.Length}";

                foreach (string fileName in dialog.FileNames)
                {
                    string filePath = System.IO.Path.GetFullPath(fileName);
                    string fileNameOnly = System.IO.Path.GetFileName(fileName);

                    // 將檔案名稱和路徑加入到 DataGridView 中
                    dataGridView1.Rows.Add(fileNameOnly, filePath);
                }
            }

            Stopwatch stopwatch = Stopwatch.StartNew();

            await Task.Run(async () =>
            {
                List<string> paths = new List<string>(filepaths);

                List<Task> tasks = new List<Task>();
                int taskcount = 200;
                int sss = (int)Math.Ceiling(paths.Count() / (double)taskcount);
                for (int i = 0; i < taskcount; i++)
                {
                    int start = i * sss;
                    var subpaths = paths.Skip(start).Take(sss).ToArray();
                    await ImageSend(subpaths);
                }

                Console.WriteLine("finish");

            });

            stopwatch.Stop();

            Console.WriteLine((stopwatch.ElapsedMilliseconds / 1000).ToString());
        }

        public async Task ImageSend(string[] paths)
        {
            await Task.Run(async () =>
            {
                string route = "DetectImage";
                string url = @"http://127.0.0.1:8888";
                foreach (string str in paths)
                {
                    var form = new MultipartFormDataContent();
                    form.Add(new ByteArrayContent(File.ReadAllBytes(str)), nameof(ByteArrayContent), Path.GetFileName(str));

                    var httpClient = new HttpClient()
                    {
                        BaseAddress = new Uri(url)
                    };

                    var response = await httpClient.PostAsync("/" + route, form);
                    response.EnsureSuccessStatusCode();

                    var responseContent = await response.Content.ReadAsStringAsync();
                    Console.WriteLine(responseContent);
                    WriteResultToCsv(responseContent, csvFileName);
                    totalReceive = totalReceive + 1;
                    txtTotalReceive.Text = $"{totalReceive}";
                }
            });
        }

        private void InitializeCsv(string csvFileName)
        {
            // 使用StringBuilder來生成CSV標題
            var csvContent = new StringBuilder();

            // 添加CSV標題
            csvContent.AppendLine("filename,pattern,shiftx,sfifty");

            // 寫入到文件
            File.WriteAllText(csvFileName, csvContent.ToString());

            Console.WriteLine($"CSV file initialized with header at {csvFileName}");
        }

        private void WriteResultToCsv(string jsonString, string csvFileName)
        {
            // 解析JSON字串
            ReceiveData receiveData = JsonConvert.DeserializeObject<ReceiveData>(jsonString);

            // 提取Result中的內容並寫入CSV
            foreach (var result in receiveData.Result)
            {
                // 將每個項目按照逗號分割
                string[] parts = result.ToString().Split(',');
                // 建立 DataContent 物件並加入列表
                var dataContent = new DataContent(
                    parts[0], // FileName
                    parts[1], // Pattern
                    parts[2], // RGB
                    double.Parse(parts[3]), // Shiftx
                    double.Parse(parts[4]), // Shifty
                    double.Parse(parts[5]), // Pnx
                    double.Parse(parts[6]), // Pny
                    double.Parse(parts[7]), // Ledx
                    double.Parse(parts[8])  // Ledy
                );
                dataList.Add(dataContent);
            }

            MultiplyValuesAndSaveToCsv();
        }

        private void displaylog(object sender, EventArgs e)
        {
            textBox1.AppendText(data);
        }


        private async void button4_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Excel Files|*.xls;*.xlsx";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = openFileDialog.FileName;

                    using (HttpClient client = new HttpClient())
                    {
                        using (var content = new MultipartFormDataContent())
                        {
                            byte[] fileBytes = File.ReadAllBytes(filePath);
                            var fileContent = new ByteArrayContent(fileBytes);
                            fileContent.Headers.ContentType = MediaTypeHeaderValue.Parse("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                            content.Add(fileContent, "file", Path.GetFileName(filePath));

                            var response = await client.PostAsync("http://127.0.0.1:8888/api/upload", content);
                            if (response.IsSuccessStatusCode)
                            {
                                MessageBox.Show("File sent successfully!");
                            }
                            else
                            {
                                MessageBox.Show("Error sending file.");
                            }
                        }
                    }
                }
            }


        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            // 清除所有舊的圖形標記
            cogDisplay1.InteractiveGraphics.Clear();
            dataGridViewDetail.Rows.Clear();
            // 獲取選中行的檔案路徑
            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
            string filePath = row.Cells[1].Value.ToString();
            //讀取DataContect
            var points = dataList.Where(entry => entry.FileName == Path.GetFileName(filePath)).ToList();

            // 顯示圖片
            Bitmap bmp = new Bitmap(Image.FromFile(filePath));
            Cognex.VisionPro.CogImage24PlanarColor image = new Cognex.VisionPro.CogImage24PlanarColor((Bitmap)bmp);
            cogDisplay1.AutoFit = true;
            cogDisplay1.Image = image;

            foreach (var point in points)
            {
                double width1 = 530;
                double height1 = 320;
                double width2 = 95;
                double height2 = 175;

                //Pattern 方形
                CogRectangle PnSquare = new CogRectangle();
                PnSquare.X = point.Pnx - width1 / 2;
                PnSquare.Y = point.Pny - height1 / 2;
                PnSquare.Width = width1;
                PnSquare.Height = height1;
                PnSquare.Color = CogColorConstants.Red;
                cogDisplay1.InteractiveGraphics.Add(PnSquare, "", false);

                //Led 方形
                CogRectangle LedSquare = new CogRectangle();
                LedSquare.X = point.Ledx - width2 / 2;
                LedSquare.Y = point.Ledy - height2 / 2;
                LedSquare.Width = width2;
                LedSquare.Height = height2;
                LedSquare.Color = CogColorConstants.Blue;
                cogDisplay1.InteractiveGraphics.Add(LedSquare, "", false);

                // Pattern 十字
                CogPointMarker PnCrossPoint = new CogPointMarker();
                PnCrossPoint.X = point.Pnx;
                PnCrossPoint.Y = point.Pny;
                PnCrossPoint.Color = CogColorConstants.Red;
                PnCrossPoint.LineStyle = CogGraphicLineStyleConstants.Solid;
                cogDisplay1.InteractiveGraphics.Add(PnCrossPoint, "", false);

                // LED 十字
                CogPointMarker LedCrossPoint = new CogPointMarker();
                LedCrossPoint.X = point.Ledx;
                LedCrossPoint.Y = point.Ledy;
                LedCrossPoint.Color = CogColorConstants.Blue;
                LedCrossPoint.LineStyle = CogGraphicLineStyleConstants.Solid;
                cogDisplay1.InteractiveGraphics.Add(LedCrossPoint, "", false);

                // 將篩選後的列表綁定到第二個 GridView
                dataGridViewDetail.Rows.Add(point.Pattern, point.RGB, point.Shiftx, point.Shifty);
            }
        }

        private void cogDisplay1_Enter(object sender, EventArgs e)
        {

        }

        private void txtBarcode_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void MultiplyValuesAndSaveToCsv()
        {
            // 從 TextBox 中取得倍數
            double PxSize = double.Parse(txtPxSize.Text);

            // 指定 CSV 檔案存放路徑 (可根據需求自訂)
            string csvFilePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "output.csv");

            // 寫入 CSV 檔案
            using (StreamWriter sw = new StreamWriter(csvFileName))
            {
                sw.WriteLine("FileName,Pattern,RGB,Shiftx,Shifty,Pnx,Pny,Ledx,Ledy");
                // 乘法操作
                foreach (var data in dataList)
                {
                    double Shiftx2um = data.Shiftx * PxSize;
                    double Shifty2um = data.Shifty * PxSize;
                    double Pnx2um = data.Pnx * PxSize;
                    double Pny2um = data.Pny * PxSize;
                    double Ledx2um = data.Ledx * PxSize;
                    double Ley2um = data.Ledy * PxSize;

                    sw.WriteLine($"{data.FileName},{data.Pattern},{data.RGB},{Shiftx2um},{Shifty2um},{Pnx2um},{Pny2um},{Ledx2um},{Ley2um}");
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtPxSize_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridViewDetail_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }

}
