﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Reflection.Emit;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace WepApiHost
{
    public static class WebApiFunctionTest
    {
        public async static Task<string> UploadStringWithHttpClientAsync(string data, string url, string route)
        {
            var form = new MultipartFormDataContent();

            form.Add(new StringContent(data), nameof(StringContent));

            var httpClient = new HttpClient()
            {
                BaseAddress = new Uri(url)
            };

            return await PostMessage(url, route, form);

        }



        public async static Task<string> UploadFileWithHttpClientAsync(string[] filePaths, string url, string route)
        {


            var form = new MultipartFormDataContent();
            if (filePaths != null)
            {
                foreach (var str in filePaths)
                {
                    form.Add(new ByteArrayContent(File.ReadAllBytes(str)), Path.GetFileName(str));
                }
            }

            return await PostMessage(url, route, form);

        }


        public async static Task<string> UploadStringWithHttpClientAsync(string[] datas, string url, string route)
        {


            var form = new MultipartFormDataContent();
            if (datas != null)
            {
                foreach (var str in datas)
                {
                    form.Add(new StringContent(str));
                }
            }

            return await PostMessage(url, route, form);

        }


        /// <summary>
        /// 帶參數   ex: ?AA=123&CC=456
        /// </summary>
        /// <param name="url"></param>
        /// <param name="route"></param>
        /// <param name="paras"></param>
        /// <param name="timeoutMs"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public static async Task<string> GetMessage(string url, string route, (string,string)[] paras,int timeoutMs = 2000)
        {
            if (paras != null)
            {
                List<string> strlist = new List<string>();
                foreach (var p in paras)
                {
                    strlist.Add(p.Item1 + "=" + p.Item2);
                }
                string routepara = route + "?" + string.Join("&", strlist.ToArray());

                return await GetMessage(url, routepara, 2000);
            }
            else
                throw new Exception();
        }



        /// <summary>
        /// 
        /// </summary>
        /// <param name="url">尾端不需要'/'</param>
        /// <param name="route"></param>
        /// <param name="timeoutMs"></param>
        /// <returns></returns>
        public static async Task<string> GetMessage(string url, string route, int timeoutMs = 2000)
        {
            try
            {
                /*
                var httpClient = new HttpClient()
                {
                    BaseAddress = new Uri(url),                  
                };


                //
                var _timeout = timeoutMs;//Timeout 時間(毫秒)
                var cts = new CancellationTokenSource(_timeout);


                var response = await httpClient.GetAsync($"/" + route, cts.Token);
                */

                var httpClient = new HttpClient()
                {
                    BaseAddress = new Uri(url),
                    Timeout = TimeSpan.FromMilliseconds(timeoutMs)
                };
                var response = await httpClient.GetAsync($"/" + route);



                response.EnsureSuccessStatusCode();


                return await response.Content.ReadAsStringAsync();
            }
            catch (Exception ex) { return ex.Message; }



        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="url"></param>
        /// <param name="route"></param>
        /// <param name="content"></param>
        /// <param name="timeoutMs"></param>
        /// <returns></returns>
        public static async Task<string> PostMessage(string url, string route, MultipartFormDataContent content, int timeoutMs = 2000)
        {
            try
            {


                var httpClient = new HttpClient()
                {
                    BaseAddress = new Uri(url),
                    Timeout = TimeSpan.FromMilliseconds(timeoutMs)
                };



                var response = await httpClient.PostAsync($"/" + route, content);

                response.EnsureSuccessStatusCode();


                return await response.Content.ReadAsStringAsync();
            }
            catch (Exception ex) { return ex.Message; }

        }
    }
}
