﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    internal class DataContent
    {
        public string FileName { get; set; }
        public string Pattern { get; set; }
        public string RGB { get; set; }
        public double Shiftx { get; set; }
        public double Shifty { get; set; }
        public double Pnx { get; set; }
        public double Pny { get; set; }
        public double Ledx { get; set; }
        public double Ledy { get; set; }

        public DataContent(string fileName, string pattern, string rgb, double shiftx, double shifty, double pnx, double pny, double ledx, double ledy)
        {
            FileName = fileName;
            Pattern = pattern;
            RGB = rgb;
            Shiftx = shiftx;
            Shifty = shifty;
            Pnx = pnx;
            Pny = pny;
            Ledx = ledx;
            Ledy = ledy;
        }
    }
}
