﻿using System;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

public class UploadController : ApiController
{
    [HttpPost]
    [Route("api/upload")]
    public async Task<IHttpActionResult> UploadFile()
    {
        if (!Request.Content.IsMimeMultipartContent())
        {
            return BadRequest("Unsupported media type");
        }

        var provider = new MultipartMemoryStreamProvider();
        await Request.Content.ReadAsMultipartAsync(provider);

        foreach (var file in provider.Contents)
        {
            var filename = file.Headers.ContentDisposition.FileName.Trim('\"');
            var buffer = await file.ReadAsByteArrayAsync();
            var filePath = Path.Combine("C:\\ReceivedFiles", filename);  // 將文件保存在本地

            File.WriteAllBytes(filePath, buffer);
        }

        return Ok("File received and saved");
    }
}