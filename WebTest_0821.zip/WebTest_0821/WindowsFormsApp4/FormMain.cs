﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WepApiHost
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();

            double.TryParse(null, out double sssss);
        }

        private void FormMain_Load(object sender, EventArgs e)
        {

          




            tabControl1.TabPages[0].Controls.Add(setform(new FormServer()));



            tabControl1.TabPages[1].Controls.Add(setform(new FormControl()));
        }


        Form setform(Form ff)
        {
            ff.Dock = DockStyle.Fill;
            ff.FormBorderStyle = FormBorderStyle.None;  //無框         
            ff.TopLevel = false;
            ff.Show();

            return ff;
        }



        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private async void button1_Click(object sender, EventArgs e)
        {
            (sender as Control).BackColor = Color.Green;

            string barcode = DateTime.Now.Ticks.ToString();


            var v = await WebApiFunctionTest.
                GetMessage("http://localhost:8888", "echo", new (string, string)[] { ("name", "phenix") });



            (sender as Control).BackColor = DefaultBackColor;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            var vvv = dataGridView1.Rows[0].Cells[0].Value;
            string str = vvv.ToString();
            double.TryParse(dataGridView1.Rows[0].Cells[0].Value.ToString(), out double compensationX);
        }


        Task<bool> ttt = Task.FromResult(false);
        private void button4_Click(object sender, EventArgs e)
        {
            if (!ttt.Result)
            {
                ttt = Task.Run(() =>
                {

                    return true;
                });
            }

           
                



        }
    }
}
