﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp.Controllers;
using System.Runtime.Remoting.Contexts;
using Newtonsoft.Json.Serialization;
using System.Xml.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Diagnostics.Eventing.Reader;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Security.Policy;

namespace WepApiHost
{
    public partial class FormControl : Form
    {
        public FormControl()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            HomeController.LogIn += HomeController_LogIn;
        }

        private void HomeController_LogIn(string obj)
        {
            this.BeginInvoke(new Action(() =>
            {
                textBox1.AppendText(DateTime.Now.ToString() + "    " + obj + Environment.NewLine);
            }));
        }


        /// <summary>
        /// Post Image to Server
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        private async Task UploadFileWithHttpClientAsync(string[] filePaths, string url, string route)
        {

            /*
            List<Task> Tasks = new List<Task>();
            foreach (var str in filePaths)
            {
                var t = Task.Run(async() =>
                {
                    var form = new MultipartFormDataContent();
                    form.Add(new ByteArrayContent(File.ReadAllBytes(str)), nameof(ByteArrayContent), Path.GetFileName(str));
                    form.Add(new StringContent(str), nameof(StringContent));

                    var httpClient = new HttpClient()
                    {
                        BaseAddress = new Uri(url)
                    };

                    var response = await httpClient.PostAsync("/" + route, form);
                    response.EnsureSuccessStatusCode();


                    var responseContent = await response.Content.ReadAsStringAsync();
                });
                Tasks.Add(t);
            }

            await Task.WhenAll(Tasks);  
            */


            
            var form = new MultipartFormDataContent();
            if (filePaths != null)
            {
                foreach (var str in filePaths)
                {

                    form.Add(new ByteArrayContent(File.ReadAllBytes(str)), nameof(ByteArrayContent), Path.GetFileName(str));
                    form.Add(new StringContent(str), nameof(StringContent));
                }
            }



            var httpClient = new HttpClient()
            {
                BaseAddress = new Uri(url)
            };

            var response = await httpClient.PostAsync("/" + route, form);
            response.EnsureSuccessStatusCode();


            var responseContent = await response.Content.ReadAsStringAsync();


            HomeController_LogIn("SEND Image ");

            //Console.WriteLine("response :" + responseContent);

            
        }


        private async Task UploadStringWithHttpClientAsync(dynamic data, string url, string route)
        {
            var jdata = data;// new { Time=DateTime.Now.ToString() , Message = $"AAAAAAAAAAAAAAAAAAAAAA" };


            string jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(jdata);



            var form = new MultipartFormDataContent();



            form.Add(new StringContent(jsonString), nameof(StringContent));






            var httpClient = new HttpClient()
            {
                BaseAddress = new Uri(url)
            };

            var response = await httpClient.PostAsync($"/" + route, form);
            var res = response.EnsureSuccessStatusCode();


            var responseContent = await response.Content.ReadAsStringAsync();


        }


        /// <summary>
        /// Request Report 
        /// </summary>
        /// <returns></returns>
        private static async Task NotifyReport(string url, bool UsePost = false)
        {

            var httpClient = new HttpClient()
            {
                BaseAddress = new Uri(url)
            };

            if (UsePost)
            {
                var form = new MultipartFormDataContent();
                var response = await httpClient.PostAsync($"/Report", form);
                response.EnsureSuccessStatusCode();
            }
            else  //get
            {
                var response = await httpClient.GetAsync($"/Report");
                response.EnsureSuccessStatusCode();
            }


            //var responseContent = await response.Content.ReadAsStringAsync();

            //Console.WriteLine("response :" + responseContent);
        }

        private async Task NotifyBarcode(string barcode, string url)
        {
            var httpClient = new HttpClient()
            {

                BaseAddress = new Uri(url)
            };

            var response = await httpClient.GetAsync($"/Barcode/" + barcode);
            response.EnsureSuccessStatusCode();
            var responseContent = await response.Content.ReadAsStringAsync();

            HomeController_LogIn(barcode);


            //Console.WriteLine("response :" + responseContent);
        }

        /// <summary>
        /// sned image
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void buttonSend_Click(object sender, EventArgs e)
        {
            (sender as Control).BackColor = Color.Green;
            string route = textBox6+"/"+ numericUpDown1.Value.ToString();   
            await UploadFileWithHttpClientAsync(filepaths, txUrl.Text, route);
            (sender as Control).BackColor = DefaultBackColor;
        }

        string filepath;
        string[] filepaths;

        private void buttonLoad_Click(object sender, EventArgs e)
        {

            //pictureBox1.Image = ConvertToBitmap(@"C:\Users\pheni\Desktop\pexels-sabel-blanco-1662549.jpg");


            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Multiselect = true;
            dialog.Title = "請選擇檔案";
            dialog.Filter = "所有檔案(*.*)|*.*";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                string filename = dialog.FileName;
                filename = dialog.FileNames[0];

               // filepath = filename;
                filepaths = dialog.FileNames;

                //textBox3.Text = string.Join(Environment.NewLine, dialog.FileNames);

                //flowLayoutPanel1.Controls.Clear();
                //foreach (string file in filepaths)
                //{
                //    PictureBox pictureBox = new PictureBox() { SizeMode = PictureBoxSizeMode.Zoom, Width = 100, Height = 100 };
                //    pictureBox.Image = Bitmap.FromFile(file);
                //    flowLayoutPanel1.Controls.Add(pictureBox);


                //}



            }
        }

        public Bitmap ConvertToBitmap(string fileName)
        {
            Bitmap bitmap;
            using (Stream bmpStream = System.IO.File.Open(fileName, System.IO.FileMode.Open))
            {
                Image image = Image.FromStream(bmpStream);

                bitmap = new Bitmap(image);

            }
            return bitmap;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void buttonReport_Click(object sender, EventArgs e)
        {
            (sender as Control).BackColor = Color.Green;
            await NotifyReport(txUrl.Text);
            (sender as Control).BackColor = DefaultBackColor;
        }

        /// <summary>
        /// Notify Barcode
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void button4_Click(object sender, EventArgs e)
        {
            (sender as Control).BackColor = Color.Green;

            string barcode = DateTime.Now.Ticks.ToString();
            textBox4.Text = barcode;

            await NotifyBarcode(barcode, txUrl.Text);
            (sender as Control).BackColor = DefaultBackColor;
        }

        private async void button5_Click(object sender, EventArgs e)
        {
            await UploadFileWithHttpClientAsync(filepaths, "http://localhost:8080", "DetectImage");
        }




        private async void button6_Click(object sender, EventArgs e)
        {

            await UploadStringWithHttpClientAsync(new { Time = DateTime.Now.ToString(), Message = $"AAAAAAAAAAAAAAAAAAAAAA" },




                "http://localhost:8080", "Reportdata");
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox4.Text = DateTime.Now.Ticks.ToString();
        }

        private async void button8_Click(object sender, EventArgs e)
        {
            (sender as Control).BackColor = Color.Green;
            await NotifyReport(txUrl.Text, true);
            (sender as Control).BackColor = DefaultBackColor;
        }

        private async void button9_Click(object sender, EventArgs e)
        {
            string url = txUrl.Text;
            //string route = textBox2.Text + "/" + textBox5.Text;
            string route = textBox6 + "/" + numericUpDown1.Value.ToString();
            int waittime = int.Parse(textBox7.Text);

            (sender as Control).BackColor = Color.Green;
            (sender as Control).Enabled = false;
            await RUN(url, route, waittime);
            (sender as Control).BackColor = DefaultBackColor;
            (sender as Control).Enabled = true;
        }


        async Task RUN(string url, string route, int waittime)
        {
            TaskCompletionSource<string> taskCompletionSource = new TaskCompletionSource<string>();

            HomeController.EventReport += HomeController_EventReport;

            await Task.Run(async () =>
            {

                string ACSDiffFilePath = @"D:\iCameraData\ReportData_" + DateTime.Now.ToString("yyyy-MM-dd HH-mm-ss fff") + ".csv";

                using (StreamWriter sw = new StreamWriter(ACSDiffFilePath, true))
                {
                    foreach (var path in filepaths)
                    {
                        taskCompletionSource = new TaskCompletionSource<string>();
                        string barcode = DateTime.Now.Ticks.ToString();
                        await NotifyBarcode(barcode, url);   //
                        await Task.Delay(waittime);
                        await UploadFileWithHttpClientAsync(new string[] { path }, url, route);    //
                        await Task.Delay(waittime);
                        await NotifyReport(url);     //
                                                     //await Task.Delay(waittime);
                        var timeout = Task.Delay(5000);
                        var v = await Task.WhenAny(taskCompletionSource.Task, timeout);
                        if (v != timeout)
                        {
                            Console.WriteLine(taskCompletionSource.Task.Result);
                        }
                        else
                        {
                            Console.WriteLine("Timeout");
                        }
                        await Task.Delay(1000);

                        WriteDataToFile(Path.GetFileNameWithoutExtension(path), taskCompletionSource.Task.Result);

                        sw.WriteLine(path + "," + taskCompletionSource.Task.Result);
                    }

                }
            });

            HomeController.EventReport -= HomeController_EventReport;

            void HomeController_EventReport(string obj)
            {
                taskCompletionSource.SetResult(obj);
            }
        }


        async void WriteDataToFile(string filename, string content)
        {
            await Task.Run(() =>
            {
                string ACSDiffFilePath = @"D:\iCameraData\" + filename + "_" + DateTime.Now.ToString("yyyy-MM-dd HH-mm-ss fff") + ".txt";
                using (StreamWriter sw = new StreamWriter(ACSDiffFilePath, true))
                {
                    sw.WriteLine($"{content}");
                }
            });
        }



        private void button10_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void txUrl_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
