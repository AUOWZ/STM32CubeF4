﻿using Cognex.VisionPro;
using Cognex.VisionPro.Blob;
using Cognex.VisionPro.ImageProcessing;
using Cognex.VisionPro.PMAlign;
using Cognex.VisionPro.QuickBuild;
using Cognex.VisionPro.ToolGroup;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Policy;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp.Controllers;
using static System.Net.WebRequestMethods;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WepApiHost
{
    public partial class FormServer : Form
    {
        public FormServer()
        {
            InitializeComponent();
        }

        private bool IsOpened;
        private HttpService _http;
        string filename;
        private async void button1_Click(object sender, EventArgs e)
        {
            (sender as Control).BackColor = Color.Green;

            /**
             * start.
             */
            try
            {
                var port = Convert.ToInt32(this.PortNum.Value);

                /**
                 * initialize http service.
                 */
                _http = new HttpService(port);

                await _http.StartHttpServer();
                
                IsOpened = true;
            }
            catch (Exception exception)
            {
                MessageBox.Show($"{exception.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            await Task.Delay(2000);
            (sender as Control).BackColor = Control.DefaultBackColor;
        }

        private async void button2_Click(object sender, EventArgs e)
        {

            try
            {
                await _http.CloseHttpServer();
                _http.Dispose();

                IsOpened = false;
            }
            catch (Exception exception)
            {
                MessageBox.Show($"{exception.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        CogJob CogJob { get; set; }
        CogToolCollection CogTools { get; set; }

        private void Form1_Load(object sender, EventArgs e)
        {
            HomeController.LogIn += HomeController_LogIn;
            HomeController.IMageshow += HomeController_IMageshow;

            //
            string vpppath = @"..\DecapJob.vpp";
            CogJob job = VisionTool.Method.LoadVisionTool<CogJob>(vpppath);

            if (job != null)
            {
                CogJob = job;
                CogTools = (job.VisionTool as CogToolGroup).Tools;
                HomeController.CogTools = CogTools;
            }
            else
            {
                MessageBox.Show("fail load vpp");
                //Environment.Exit(0);
            }


        }

        private void HomeController_IMageshow(Bitmap obj, string fileName)
        {
            this.BeginInvoke(new Action(() =>
            {
                textBox1.AppendText(DateTime.Now.ToString() + "    " + fileName + Environment.NewLine);

                var bmp = obj;

                Cognex.VisionPro.CogImage8Grey image = new Cognex.VisionPro.CogImage8Grey((Bitmap)bmp);

                //cogDisplay1.Image = image;

            }));
        }

        private void HomeController_LogIn(string obj)
        {
            this.BeginInvoke(new Action(() =>
            {
                textBox1.AppendText(DateTime.Now.ToString() + "    " + obj + Environment.NewLine);

            }));
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.BackColor = IsOpened ? Color.GreenYellow : Color.White;
        }


        private async Task UploadFileWithHttpClientAsync(string[] filePaths, string url, string route)
        {

            // MultipartFormDataContent收集文件數據
            var form = new MultipartFormDataContent();

            if (filePaths != null)
            {
                foreach (var str in filePaths)
                {
                    //添加文件參數,參數名稱
                    form.Add(new ByteArrayContent(System.IO.File.ReadAllBytes(str)), nameof(ByteArrayContent), Path.GetFileName(str));
                    //form.Add(new StringContent(str), nameof(StringContent));
                }
            }



            var httpClient = new HttpClient()
            {
                BaseAddress = new Uri(url)
            };


            // 傳送目標 "/" + route ; 傳送內容 form
            var response = await httpClient.PostAsync("/" + route, form);
            response.EnsureSuccessStatusCode();

            //讀取回應內容
            var responseContent = await response.Content.ReadAsStringAsync();


            //HomeController_LogIn("SEND Image ");

            //Console.WriteLine("response :" + responseContent);


        }

        private void Display(object sender, EventArgs e)
        {
            textBox1.Text = filename;
        }

        private void PortNum_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void cogDisplay1_Enter(object sender, EventArgs e)
        {

        }

        private void btnLoadVpp_Click(object sender, EventArgs e)
        {
            //Load vpp button
            string vpppath = @"..\DecapJob.vpp";
            CogJob job = VisionTool.Method.LoadVisionTool<CogJob>(vpppath);

            if (job != null)
            {
                CogJob = job;
                CogTools = (job.VisionTool as CogToolGroup).Tools;
            }
        }

        private void btnSaveVPP_Click(object sender, EventArgs e)
        {
            //Save vpp button
            string vppsavepath = @"..\DecapJob.vpp";
            VisionTool.Method.SaveVisionTool<CogJob>(CogJob, vppsavepath);
        }

        private void btnCogPMAlignTool1_Click(object sender, EventArgs e)
        {
            var tool = CogTools["CogPMAlignTool1"];
            VisionTool.FormPMAlign f = new VisionTool.FormPMAlign((CogPMAlignTool)tool);
            f.ShowDialog();
        }

        private void btnCogPMAlignTool2_Click(object sender, EventArgs e)
        {
            var tool = CogTools["CogPMAlignTool2"];
            VisionTool.FormPMAlign f = new VisionTool.FormPMAlign((CogPMAlignTool)tool);
            f.ShowDialog();
        }

        private void btnCogBlobTool1_Click(object sender, EventArgs e)
        {
            var tool = CogTools["CogBlobTool1"];
            VisionTool.FormBlob f = new VisionTool.FormBlob((CogBlobTool)tool);
            f.ShowDialog();
        }
    }
}
