﻿namespace WepApiHost
{
    partial class FormServer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.PortNum = new System.Windows.Forms.NumericUpDown();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.btnLoadVpp = new System.Windows.Forms.Button();
            this.btnSaveVPP = new System.Windows.Forms.Button();
            this.btnCogPMAlignTool1 = new System.Windows.Forms.Button();
            this.btnCogPMAlignTool2 = new System.Windows.Forms.Button();
            this.btnCogBlobTool1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.PortNum)).BeginInit();
            this.SuspendLayout();
            // 
            // PortNum
            // 
            this.PortNum.Location = new System.Drawing.Point(7, 24);
            this.PortNum.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.PortNum.Name = "PortNum";
            this.PortNum.Size = new System.Drawing.Size(206, 22);
            this.PortNum.TabIndex = 0;
            this.PortNum.Value = new decimal(new int[] {
            8888,
            0,
            0,
            0});
            this.PortNum.ValueChanged += new System.EventHandler(this.PortNum_ValueChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(301, 9);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(88, 42);
            this.button1.TabIndex = 1;
            this.button1.Text = "Open";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(395, 9);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(88, 42);
            this.button2.TabIndex = 2;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox1
            // 
            this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox1.Location = new System.Drawing.Point(7, 78);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1.Size = new System.Drawing.Size(476, 696);
            this.textBox1.TabIndex = 3;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Location = new System.Drawing.Point(219, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 42);
            this.label1.TabIndex = 4;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 9;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(0, 0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 8;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(0, 0);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 0;
            // 
            // btnLoadVpp
            // 
            this.btnLoadVpp.Location = new System.Drawing.Point(500, 16);
            this.btnLoadVpp.Name = "btnLoadVpp";
            this.btnLoadVpp.Size = new System.Drawing.Size(126, 29);
            this.btnLoadVpp.TabIndex = 25;
            this.btnLoadVpp.Text = "Load VPP";
            this.btnLoadVpp.UseVisualStyleBackColor = true;
            this.btnLoadVpp.Click += new System.EventHandler(this.btnLoadVpp_Click);
            // 
            // btnSaveVPP
            // 
            this.btnSaveVPP.Location = new System.Drawing.Point(641, 16);
            this.btnSaveVPP.Name = "btnSaveVPP";
            this.btnSaveVPP.Size = new System.Drawing.Size(126, 29);
            this.btnSaveVPP.TabIndex = 26;
            this.btnSaveVPP.Text = "Save VPP";
            this.btnSaveVPP.UseVisualStyleBackColor = true;
            this.btnSaveVPP.Click += new System.EventHandler(this.btnSaveVPP_Click);
            // 
            // btnCogPMAlignTool1
            // 
            this.btnCogPMAlignTool1.Location = new System.Drawing.Point(568, 78);
            this.btnCogPMAlignTool1.Name = "btnCogPMAlignTool1";
            this.btnCogPMAlignTool1.Size = new System.Drawing.Size(126, 29);
            this.btnCogPMAlignTool1.TabIndex = 27;
            this.btnCogPMAlignTool1.Text = "CogPMAlignTool1";
            this.btnCogPMAlignTool1.UseVisualStyleBackColor = true;
            this.btnCogPMAlignTool1.Click += new System.EventHandler(this.btnCogPMAlignTool1_Click);
            // 
            // btnCogPMAlignTool2
            // 
            this.btnCogPMAlignTool2.Location = new System.Drawing.Point(568, 129);
            this.btnCogPMAlignTool2.Name = "btnCogPMAlignTool2";
            this.btnCogPMAlignTool2.Size = new System.Drawing.Size(126, 29);
            this.btnCogPMAlignTool2.TabIndex = 28;
            this.btnCogPMAlignTool2.Text = "CogPMAlignTool2";
            this.btnCogPMAlignTool2.UseVisualStyleBackColor = true;
            this.btnCogPMAlignTool2.Click += new System.EventHandler(this.btnCogPMAlignTool2_Click);
            // 
            // btnCogBlobTool1
            // 
            this.btnCogBlobTool1.Location = new System.Drawing.Point(568, 182);
            this.btnCogBlobTool1.Name = "btnCogBlobTool1";
            this.btnCogBlobTool1.Size = new System.Drawing.Size(126, 29);
            this.btnCogBlobTool1.TabIndex = 29;
            this.btnCogBlobTool1.Text = "CogBlobTool1";
            this.btnCogBlobTool1.UseVisualStyleBackColor = true;
            this.btnCogBlobTool1.Click += new System.EventHandler(this.btnCogBlobTool1_Click);
            // 
            // FormServer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1434, 786);
            this.Controls.Add(this.btnCogBlobTool1);
            this.Controls.Add(this.btnCogPMAlignTool2);
            this.Controls.Add(this.btnCogPMAlignTool1);
            this.Controls.Add(this.btnSaveVPP);
            this.Controls.Add(this.btnLoadVpp);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PortNum);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "FormServer";
            this.Text = "FormServer";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PortNum)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown PortNum;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button btnLoadVpp;
        private System.Windows.Forms.Button btnSaveVPP;
        private System.Windows.Forms.Button btnCogPMAlignTool1;
        private System.Windows.Forms.Button btnCogPMAlignTool2;
        private System.Windows.Forms.Button btnCogBlobTool1;
    }
}

