﻿using Cognex.VisionPro;
using Cognex.VisionPro.Blob;
using Cognex.VisionPro.ImageProcessing;
using Cognex.VisionPro.PMAlign;
using Cognex.VisionPro.QuickBuild;
using Org.BouncyCastle.Asn1.Crmf;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Results;
using static WepApiHost.FormServer;


namespace WindowsFormsApp.Controllers
{
    /// <summary>
    /// Home controller.
    /// </summary>
    //[RoutePrefix("api/home")]
    //[RoutePrefix("controller")]
    public class HomeController : ApiController
    {

        public static CogJob CogJob { get; set; }
        public static CogToolCollection CogTools { get; set; }
        public static event Action<string> LogIn;
        public delegate void ImageShowDelegate(Bitmap bitmap, string fileName);
        public static event ImageShowDelegate IMageshow;
        List <string> Result2Client = new List<string>();
        public static  Func<(string, Bitmap)[] , Task<(bool, Result[])>> ProcessImageFunc;

        public static event Action<string> EventReport;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        [Route("echo")]
        [HttpGet]
        public async Task<IHttpActionResult> Echo(string name)
        {
            LogIn?.Invoke(name);
            await Task.Delay(5000);
            return Json(new { Name = name, Message = $"Hello, {name}" });
        }


        [Route("Time")]
        [HttpGet]
        public IHttpActionResult GetTime()
        {
            LogIn?.Invoke(DateTime.Now.ToString());
            return Json(new { Time = DateTime.Now.ToString() });
        }



        /// <summary>
        /// for icamera report data
        /// </summary>
        /// <returns></returns>
        [Route("ReportData")]
        [HttpPost]
        public async Task<IHttpActionResult> ReportData()
        {
            LogIn?.Invoke("ReportData");



            var t = Request.Content.ReadAsStringAsync();
            var v = await Task.WhenAny(t, Task.Delay(TimeSpan.FromSeconds(5)));
            if (v == t)
            {
                Debug.WriteLine("SUCCESS");
                LogIn?.Invoke(t.Result);

                EventReport?.BeginInvoke(t.Result, null, null);
            }
            else
            {
                Debug.WriteLine("timeout");
                LogIn?.Invoke("Timeout");
                EventReport?.BeginInvoke("Timeout", null, null);
            }



            return Json(new { time = DateTime.Now });

        }



        /// <summary>
        /// simulation
        /// </summary>
        /// <returns></returns>
        [Route("DetectImage")]
        [HttpPost]
        public async Task<IHttpActionResult> DetectImage()
        {

            Bitmap bitmap = null;
            string fileName = null;
            List<(string, Bitmap)> images = new List<(string, Bitmap)>();

            var multi = await Request.Content.ReadAsMultipartAsync();

            Debug.WriteLine("===== Get from file =====");
            foreach (var content in multi.Contents)
            {
                string key = content.Headers.ContentDisposition.Name;
                fileName = content.Headers.ContentDisposition.FileName?.Trim('"');
                string value = string.Empty;

                using (Stream s = content.ReadAsStreamAsync().Result)
                using (var memoryStream = new MemoryStream())
                {
                    await s.CopyToAsync(memoryStream);
                    var bytes = memoryStream.ToArray();
                    if (!string.IsNullOrEmpty(key))
                    {
                        //string filePath = Path.Combine(@"C:\tmp\", fileName);
                       // File.WriteAllBytes(filePath, bytes);
                        memoryStream.Seek(0, SeekOrigin.Begin); 
                        bitmap = (Bitmap)Bitmap.FromStream(memoryStream);
                    }
                    else
                    {
                        LogIn?.Invoke(System.Text.Encoding.UTF8.GetString(bytes));
                    }
                }

            }

            //IMageshow?.Invoke(bitmap, fileName);
            images.Add((fileName, bitmap));

            var vv = await RunProcess(images.ToArray());

            //csv 
            if (vv.Item1)
            {
                {

                    foreach (var rr in vv.Item2)
                    {
                        Result result = rr;
                        int rgbIndex = 0; // 初始化RGB索引

                        foreach (var pad in result.ResultData.Keys)
                        {
                            foreach (var shiftxy in result.ResultData[pad])
                            {
                                // 获取当前RGB顺序
                                string currentRgb = GetRgbOrder(rgbIndex);

                                // 將 shiftx 和 sfifty 乘上當前的轉換值
                                double shiftxConverted = shiftxy.Item1 ;
                                double sfiftyConverted = shiftxy.Item2 ;
                                double pn_x_Converted = shiftxy.Item3 ;
                                double pn_y_Converted = shiftxy.Item4 ;
                                double led_x_Converted = shiftxy.Item5 ;
                                double led_y_Converted = shiftxy.Item6 ;
                                string str = rr.filename + "," + pad.ToString() + "," + currentRgb + "," + shiftxConverted + "," + sfiftyConverted + "," + pn_x_Converted + "," + pn_y_Converted + "," + led_x_Converted + "," + led_y_Converted;
                                Result2Client.Add(str);
                            }
                        }
                    }
                }
            }
            return Json(new { time = HttpStatusCode.OK, Result2Client });
        }

        TaskCompletionSource<bool> JobStop = new TaskCompletionSource<bool>();
        async Task<(bool, Result[])> RunProcess((string, Bitmap)[] ImageData)
        {
            JobStop = new TaskCompletionSource<bool>();

            return await Task.Run(() => {

                List<Result> ResultList = new List<Result>();
                foreach (var data in ImageData)
                {
                    if (!JobStop.Task.Wait(0))
                    {
                        CogImage8Grey grayimage = new CogImage8Grey(data.Item2);

                        var v = DoProcess(grayimage);

                        if (v.Item1)
                        {
                            Result result = new Result();
                            result.filename = data.Item1;
                            result.ResultData = v.Item3;
                            ResultList.Add(result);
                        }
                    }
                    else
                    {
                        return (false, ResultList.ToArray());
                    }
                }
                return (true, ResultList.ToArray());
            });
            //return (true, ResultList.ToArray())
        }



        (bool, int, Dictionary<int, List<(double, double, double, double, double, double)>>) DoProcess(CogImage8Grey image)
        {
            var pm1 = CogTools["CogPMAlignTool1"] as CogPMAlignTool;
            var pm2 = CogTools["CogPMAlignTool2"] as CogPMAlignTool;
            var blob = CogTools["CogBlobTool1"] as CogBlobTool;

            //var toolsubgroup = new CogToolGroup();
            //toolsubgroup.Tools.Add(pm1);

            //toolsubgroup.Tools["CogPMAlignTool1"].Run();

            Dictionary<int, List<(double, double, double, double, double, double)>> shiftresult = new Dictionary<int, List<(double, double, double, double, double, double)>>();


            //Step 0
            pm1.InputImage = image;
            pm1.Run();
            if (pm1.RunStatus.Result != CogToolResultConstants.Accept)
                return (false, CogTools.IndexOf(pm1), null);

            var results = pm1.Results;

            if (results.Count <= 0)
                return (false, CogTools.IndexOf(pm1), null);

            List<CogPMAlignResult> pattern_list = new List<CogPMAlignResult>();
            foreach (CogPMAlignResult result in results)
                pattern_list.Add(result);

            // 获取画面中心的坐标
            double centerX = (pattern_list.Max(r => r.GetPose().TranslationX) + pattern_list.Min(r => r.GetPose().TranslationX)) / 2;
            double centerY = (pattern_list.Max(r => r.GetPose().TranslationY) + pattern_list.Min(r => r.GetPose().TranslationY)) / 2;

            // 根据每个坐标相对于中心的象限对其进行排序
            var sortedList = pattern_list.OrderBy(r => GetQuadrant(r, centerX, centerY)).ToList();

            foreach (var item in sortedList)
            {
                Console.WriteLine(item.GetPose().TranslationX + ", " + item.GetPose().TranslationY);
            }



            int padIndex = 0;

            //Step 1 find pattern
            foreach (CogPMAlignResult result in results)
            {
                //var AnalysisTool = CogTools["CogResultsAnalysisTool1"] as CogResultsAnalysisTool;
                //(AnalysisTool.RunParams["TransX"] as CogResultsAnalysisInputExpression).Value = result.GetPose().TranslationX;
                //(AnalysisTool.RunParams["TransY"] as CogResultsAnalysisInputExpression).Value = result.GetPose().TranslationY;


                //(AnalysisTool.RunParams["X"] as CogResultsAnalysisInputExpression).Value = results.GetTrainArea().X;
                //(AnalysisTool.RunParams["Y"] as CogResultsAnalysisInputExpression).Value = results.GetTrainArea().Y;


                shiftresult[++padIndex] = new List<(double, double, double, double, double, double)>();


                var score = result.Score;
                var x = result.GetPose().TranslationX;
                var y = result.GetPose().TranslationY;
                var tx = results.GetTrainArea().X;
                var ty = results.GetTrainArea().Y;

                var rx = x + tx;
                var ry = y + ty;

                //
                var tool = CogTools["CogIPOneImageTool1"] as CogIPOneImageTool;
                (tool.Region as CogRectangle).X = rx;
                (tool.Region as CogRectangle).Y = ry;
                (tool.Region as CogRectangle).Height = results.GetTrainArea().Height;
                (tool.Region as CogRectangle).Width = results.GetTrainArea().Width;
                tool.InputImage = image;
                tool.Run();

                if (tool.RunStatus.Result != CogToolResultConstants.Accept)
                    return (false, CogTools.IndexOf(tool), null);

                //
                var outputimage = tool.OutputImage;

                //
                pm2.InputImage = outputimage;
                pm2.Run();

                if (pm2.RunStatus.Result != CogToolResultConstants.Accept)
                    return (false, CogTools.IndexOf(pm2), null);

                var results2 = pm2.Results;

                if (results2.Count <= 0)
                    return (false, CogTools.IndexOf(pm2), null);

                //
                List<CogPMAlignResult> resultlist = new List<CogPMAlignResult>();
                foreach (CogPMAlignResult r in results2)
                    resultlist.Add(r);
                resultlist = resultlist.OrderBy(r => r.GetPose().TranslationY).ToList();


                //
                foreach (CogPMAlignResult result2 in resultlist)
                //foreach (CogPMAlignResult result2 in results2)
                {

                    var sss = result2.Score;
                    Console.WriteLine(sss.ToString());
                    var xx = result2.GetPose().TranslationX;
                    var yy = result2.GetPose().TranslationY;
                    var centerx = results2.GetTrainArea().CenterX;
                    var centery = results2.GetTrainArea().CenterY;
                    var txx = results2.GetTrainArea().X;
                    var tyy = results2.GetTrainArea().Y;

                    var ex = xx - centerx;
                    var ey = yy - centery;
                    var rxx = ex + txx;
                    var ryy = ey + tyy;


                    blob.InputImage = outputimage;
                    (blob.Region as CogRectangle).X = rxx;
                    (blob.Region as CogRectangle).Y = ryy;
                    (blob.Region as CogRectangle).Height = results2.GetTrainArea().Height;
                    (blob.Region as CogRectangle).Width = results2.GetTrainArea().Width;
                    blob.Run();

                    if (blob.RunStatus.Result != CogToolResultConstants.Accept)
                        continue; // return (false, CogTools.IndexOf(blob));

                    var blobresuts = blob.Results;
                    if (blobresuts.GetBlobs().Count <= 0)
                        continue; // return (false, CogTools.IndexOf(blob));



                    //rgb
                    foreach (CogBlobResult blobresult in blobresuts.GetBlobs())
                    {
                        var MassX = blobresult.CenterOfMassX;
                        var MassY = blobresult.CenterOfMassY;

                        var shiftX = MassX - xx;
                        var shiftY = yy - MassY;

                        Console.WriteLine(shiftX.ToString() + " " + shiftY.ToString());

                        shiftresult[padIndex].Add((shiftX, shiftY, xx, yy, MassX, MassY));

                    }

                }




                //Console.WriteLine(score);   
            }



            //
            return (true, -1, shiftresult);
        }



        static int GetQuadrant(CogPMAlignResult result, double centerX, double centerY)
        {
            var pose = result.GetPose();
            if (pose.TranslationX <= centerX && pose.TranslationY <= centerY) return 1; // 左下角
            if (pose.TranslationX > centerX && pose.TranslationY <= centerY) return 2;  // 右下角
            if (pose.TranslationX <= centerX && pose.TranslationY > centerY) return 3;  // 左上角
            if (pose.TranslationX > centerX && pose.TranslationY > centerY) return 4;   // 右上角
            return 0;
        }

        // 返回"R", "G", "B"基于当前的循环顺序
        public string GetRgbOrder(int index)
        {
            string[] order = { "B", "G", "R" };
            return order[index % 3];
        }

        public class Result
        {
            public string filename;
            public Dictionary<int, List<(double, double, double, double, double, double)>> ResultData = new Dictionary<int, List<(double, double, double, double, double, double)>>();
        }






        //[HttpGet]
        //[Route("[action]/{id}")]
        //public string EchoId(int id)
        //{
        //    return id.ToString();
        //}




        //[Route("detectData2")]
        //[HttpPost]
        //public IHttpActionResult DetectData2(string data)
        //{
        //    LogIn?.Invoke(data);
        //    return Json(new { time = DateTime.Now });
        //}

        //[Route("SaveNewValue")]
        //[HttpPost]
        //public void SaveNewValue([FromBody] string value)
        //{
        //    Console.WriteLine(value);   
        //}





        //[Route("Barcode")]
        //[HttpPost]
        //public IHttpActionResult getimage2(string name)
        //{
        //    return Json(new { Name = name, Message = $"Hello, {name}" });
        //}
    }
}
