﻿using Cognex.VisionPro;
using Cognex.VisionPro.Blob;
using Cognex.VisionPro.ImageProcessing;
using Cognex.VisionPro.PMAlign;
using Cognex.VisionPro.QuickBuild;
using Cognex.VisionPro.ResultsAnalysis;
using Cognex.VisionPro.ToolGroup;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Markup;
using System.Windows.Media.TextFormatting;
using System.Windows.Shapes;

namespace VisionTest_01
{

    public partial class FormMain : Form
    {

        public FormMain()
        {
            InitializeComponent();

        }


        CogJob CogJob { get; set; }
        CogToolCollection CogTools { get; set; }

        private void FormMain_Load(object sender, EventArgs e)
        {
            string vpppath = @"..\DecapJob.vpp";
            CogJob job = VisionTool.Method.LoadVisionTool<CogJob>(vpppath);

            if (job != null)
            {
                CogJob = job;
                CogTools = (job.VisionTool as CogToolGroup).Tools;
            }
            else
            {
                MessageBox.Show("fail load vpp");
                Environment.Exit(0);
            }


            //CogToolCollection Tools = (job.VisionTool as CogToolGroup).Tools;
            //var tool = Tools["CogImageConvertTool1"];

            // CogBlobTool blob = new CogBlobTool();
            // Tools.Add(blob);

            // string vppsavepath = @"..\DecapJob_.vpp";
            //VisionTool.Method.SaveVisionTool<CogJob>(job, vppsavepath);
        }

        string filepath;
        string[] filepaths;

        private void button1_Click(object sender, EventArgs e)
        {
            // Load Image button
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Multiselect = true;
            dialog.Title = "請選擇檔案";
            dialog.Filter = "所有檔案(*.*)|*.*";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                string filename = dialog.FileName;
                filename = dialog.FileNames[0];

                filepath = filename;
                filepaths = dialog.FileNames;

                var filenames = filepaths.Select(f => System.IO.Path.GetFileName(f));

                //textBox3.Text = string.Join(Environment.NewLine, filenames);


                var items = filenames.Select(i => new ListViewItem(i));
                listView1.Items.AddRange(items.ToArray());


            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // button 2 
            var tool = CogTools["CogPMAlignTool1"];
            VisionTool.FormPMAlign f = new VisionTool.FormPMAlign((CogPMAlignTool)tool);
            f.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // button 4
            var tool = CogTools["CogPMAlignTool2"];
            VisionTool.FormPMAlign f = new VisionTool.FormPMAlign((CogPMAlignTool)tool);
            f.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // button 5
            var tool = CogTools["CogBlobTool1"];
            VisionTool.FormBlob f = new VisionTool.FormBlob((CogBlobTool)tool);
            f.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //Save vpp button
            string vppsavepath = @"..\DecapJob.vpp";
            VisionTool.Method.SaveVisionTool<CogJob>(CogJob, vppsavepath);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            //Load vpp button
            string vpppath = @"..\DecapJob.vpp";
            CogJob job = VisionTool.Method.LoadVisionTool<CogJob>(vpppath);

            if (job != null)
            {
                CogJob = job;
                CogTools = (job.VisionTool as CogToolGroup).Tools;
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void button3_Click(object sender, EventArgs e)
        {
            // RUN button
            (sender as Control).BackColor = Color.Yellow;
            (sender as Control).Enabled = false;

            List<(string, Bitmap)> images = new List<(string, Bitmap)>();

            await Task.Run(() =>
            {
                foreach (var str in filepaths)
                {
                    images.Add((str, (Bitmap)Bitmap.FromFile(str)));
                }
            });

            //
            var vv = await RunProcess(images.ToArray());


            //csv 
            if(vv.Item1)
            {
                string csv = @"..\ShiftResult_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".csv";

                using (StreamWriter sw = new StreamWriter(csv))
                {
                    //title
                    sw.WriteLine("filename,pattern,shiftx,sfifty");

                    foreach (var rr in vv.Item2)
                    {
                        Result result = rr;

                        foreach (var pad in result.ResultData.Keys)
                        {
                            foreach (var shiftxy in result.ResultData[pad])
                            {
                                string str = rr.filename + "," + pad.ToString() + "," + shiftxy.Item1 + "," + shiftxy.Item2;
                                sw.WriteLine(str);
                            }
                        }
                    }
                    //sw.WriteLine(vv.Item1.ToString());
                }
            }



            (sender as Control).BackColor = DefaultBackColor;
            (sender as Control).Enabled = true;
        }

        class Result
        {
            public string filename;


            public Dictionary<int, List<(double,double)>> ResultData = new Dictionary<int, List<(double, double)>>();


        }

        TaskCompletionSource<bool> JobStop = new TaskCompletionSource<bool>();
        async Task<(bool, Result[])> RunProcess((string , Bitmap)[] ImageData)
        {
            JobStop = new TaskCompletionSource<bool>();

            return await Task.Run(() => {

                List<Result> ResultList = new List<Result>();
                foreach (var data in ImageData)
                {
                    if (!JobStop.Task.Wait(0))
                    {
                        CogImage8Grey grayimage = new CogImage8Grey(data.Item2);


                        var v = DoProcess(grayimage);

                        if (v.Item1)
                        {
                            Result result = new Result();
                            result.filename = data.Item1;
                            result.ResultData = v.Item3;
                            ResultList.Add(result);
                        }

                    }
                    else
                    {
                        return (false, ResultList.ToArray());
                    }


                }

                return (true, ResultList.ToArray());

            });

        }


        static int GetQuadrant(CogPMAlignResult result, double centerX, double centerY)
        {
            var pose = result.GetPose();
            if (pose.TranslationX <= centerX && pose.TranslationY <= centerY) return 1; // 左下角
            if (pose.TranslationX > centerX && pose.TranslationY <= centerY) return 2;  // 右下角
            if (pose.TranslationX <= centerX && pose.TranslationY > centerY) return 3;  // 左上角
            if (pose.TranslationX > centerX && pose.TranslationY > centerY) return 4;   // 右上角
            return 0;
        }
        //
        (bool,int, Dictionary<int, List<(double, double)>>) DoProcess(CogImage8Grey image)
        {
            var pm1 = CogTools["CogPMAlignTool1"] as CogPMAlignTool;
            var pm2 = CogTools["CogPMAlignTool2"] as CogPMAlignTool;
            var blob = CogTools["CogBlobTool1"] as CogBlobTool;

            //var toolsubgroup = new CogToolGroup();
            //toolsubgroup.Tools.Add(pm1);

            //toolsubgroup.Tools["CogPMAlignTool1"].Run();

            Dictionary<int, List<(double, double)>> shiftresult = new Dictionary<int, List<(double, double)>>();


            //Step 0
            pm1.InputImage = image;
            pm1.Run();
            if (pm1.RunStatus.Result != CogToolResultConstants.Accept)
                return (false, CogTools.IndexOf(pm1),null);

            var results = pm1.Results;

            if (results.Count <= 0)
                return (false, CogTools.IndexOf(pm1), null);

            List<CogPMAlignResult> pattern_list = new List<CogPMAlignResult>();
            foreach (CogPMAlignResult result in results)
                pattern_list.Add(result);

            // 获取画面中心的坐标
            double centerX = (pattern_list.Max(r => r.GetPose().TranslationX) + pattern_list.Min(r => r.GetPose().TranslationX)) / 2;
            double centerY = (pattern_list.Max(r => r.GetPose().TranslationY) + pattern_list.Min(r => r.GetPose().TranslationY)) / 2;

            // 根据每个坐标相对于中心的象限对其进行排序
            var sortedList = pattern_list.OrderBy(r => GetQuadrant(r, centerX, centerY)).ToList();

            foreach (var item in sortedList)
            {
                Console.WriteLine(item.GetPose().TranslationX + ", " + item.GetPose().TranslationY);
            }



            int padIndex = 0;

            //Step 1 find pattern
            foreach (CogPMAlignResult result in results)
            {
                //var AnalysisTool = CogTools["CogResultsAnalysisTool1"] as CogResultsAnalysisTool;
                //(AnalysisTool.RunParams["TransX"] as CogResultsAnalysisInputExpression).Value = result.GetPose().TranslationX;
                //(AnalysisTool.RunParams["TransY"] as CogResultsAnalysisInputExpression).Value = result.GetPose().TranslationY;


                //(AnalysisTool.RunParams["X"] as CogResultsAnalysisInputExpression).Value = results.GetTrainArea().X;
                //(AnalysisTool.RunParams["Y"] as CogResultsAnalysisInputExpression).Value = results.GetTrainArea().Y;



                shiftresult[++padIndex] = new List<(double, double)>();


                var score = result.Score;
                var x = result.GetPose().TranslationX;
                var y = result.GetPose().TranslationY;
                var tx = results.GetTrainArea().X;
                var ty = results.GetTrainArea().Y;

                var rx = x + tx;
                var ry = y + ty;

                //
                var tool = CogTools["CogIPOneImageTool1"] as CogIPOneImageTool;
                (tool.Region as CogRectangle).X = rx;
                (tool.Region as CogRectangle).Y = ry;
                (tool.Region as CogRectangle).Height = results.GetTrainArea().Height;
                (tool.Region as CogRectangle).Width = results.GetTrainArea().Width;
                tool.InputImage = image;
                tool.Run();

                if (tool.RunStatus.Result != CogToolResultConstants.Accept)
                    return (false, CogTools.IndexOf(tool), null);

                //
                var outputimage = tool.OutputImage;

                //
                pm2.InputImage = outputimage;
                pm2.Run();

                if (pm2.RunStatus.Result != CogToolResultConstants.Accept)
                    return (false, CogTools.IndexOf(pm2),null);

                var results2 = pm2.Results;

                if (results2.Count <= 0)
                    return (false, CogTools.IndexOf(pm2), null);

                //
                List<CogPMAlignResult> resultlist = new List<CogPMAlignResult>();
                foreach (CogPMAlignResult r in results2)
                    resultlist.Add(r);
                resultlist = resultlist.OrderBy(r=>r.GetPose().TranslationY).ToList();


                //
                foreach (CogPMAlignResult result2 in resultlist)
                //foreach (CogPMAlignResult result2 in results2)
                {

                    var sss = result2.Score;
                    Console.WriteLine(sss.ToString());
                    var xx = result2.GetPose().TranslationX;
                    var yy = result2.GetPose().TranslationY;
                    var centerx = results2.GetTrainArea().CenterX;
                    var centery = results2.GetTrainArea().CenterY;
                    var txx = results2.GetTrainArea().X;
                    var tyy = results2.GetTrainArea().Y;

                    var ex = xx - centerx;
                    var ey = yy - centery;
                    var rxx = ex + txx;
                    var ryy = ey + tyy;


                    blob.InputImage = outputimage;
                    (blob.Region as CogRectangle).X = rxx;
                    (blob.Region as CogRectangle).Y = ryy;
                    (blob.Region as CogRectangle).Height = results2.GetTrainArea().Height;
                    (blob.Region as CogRectangle).Width = results2.GetTrainArea().Width;
                    blob.Run();

                    if (blob.RunStatus.Result != CogToolResultConstants.Accept)
                        continue; // return (false, CogTools.IndexOf(blob));

                    var blobresuts = blob.Results;
                    if (blobresuts.GetBlobs().Count <= 0)
                        continue; // return (false, CogTools.IndexOf(blob));

                  

                    //rgb
                    foreach (CogBlobResult blobresult in blobresuts.GetBlobs())
                    {
                        var MassX = blobresult.CenterOfMassX;
                        var MassY = blobresult.CenterOfMassY;

                        var shiftX = MassX - xx;
                        var shiftY = yy - MassY;

                        Console.WriteLine(shiftX.ToString() + " " + shiftY.ToString());

                        shiftresult[padIndex].Add((shiftX,shiftY));

                    }

                }




                //Console.WriteLine(score);   
            }



            //
            return (true, -1, shiftresult);
        }



        private void button8_Click(object sender, EventArgs e)
        {
            JobStop.SetResult(true);
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
