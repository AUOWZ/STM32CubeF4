﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        private string Message;
        private int FocusingTimes=1;
        string receivedData;
        TaskCompletionSource<bool> taskCompletionSource = new TaskCompletionSource<bool>();
        private static ManualResetEvent DataRcvEvnt = new ManualResetEvent(false);

        private bool isPaused = false;
        private VerticalProgressBar VBarSa;
        private VerticalProgressBar VBarSb;
        private VerticalProgressBar VBarIa;
        private VerticalProgressBar VBarIb;

        public Form1()
        {
            InitializeComponent();
            VBarSa = new VerticalProgressBar
            {
                Minimum = 0,
                Maximum = 5000,
                Value = 0,
                Width = 68,
                Height = 138,
                Location = new Point(61, 21),
                BackColor = Color.LightGray // 設置背景顏色
            };

            VBarSb = new VerticalProgressBar
            {
                Minimum = 0,
                Maximum = 5000,
                Value = 0,
                Width = 68,
                Height = 138,
                Location = new Point(273, 21),
                BackColor = Color.LightGray // 設置背景顏色
            };

            VBarIa = new VerticalProgressBar
            {
                Minimum = 0,
                Maximum = 5000,
                Value = 0,
                Width = 68,
                Height = 138,
                Location = new Point(61, 21),
                BackColor = Color.LightGray // 設置背景顏色
            };

            VBarIb = new VerticalProgressBar
            {
                Minimum = 0,
                Maximum = 5000,
                Value = 0,
                Width = 68,
                Height = 138,
                Location = new Point(273, 21),
                BackColor = Color.LightGray // 設置背景顏色
            };

            // 添加進度條到表單
            SensorVolt.Controls.Add(VBarSa);
            SensorVolt.Controls.Add(VBarSb);
            IntegerVolt.Controls.Add(VBarIa);
            IntegerVolt.Controls.Add(VBarIb);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboboxComport.Items.Clear();

            // 獲取所有 COM 埠名稱
            string[] portNames = SerialPort.GetPortNames();

            // 將每個 COM 埠名稱添加到 ComboBox 中
            foreach (string portName in portNames)
            {
                comboboxComport.Items.Add(portName);
            }

            // 設置預設選中的項目（如果有可用的 COM 埠）
            if (comboboxComport.Items.Count > 0)
            {
                comboboxComport.SelectedIndex = 0;
            }

        }

        TaskCompletionSource<bool>　sfsd = new TaskCompletionSource<bool>();

        public void ComportConnectButton_Click(object sender, EventArgs e)
        {
            string selectedPort = comboboxComport.SelectedItem.ToString();
            serialPort = new SerialPort();
            serialPort.PortName = selectedPort;
            serialPort.BaudRate = 19200;
            serialPort.DataBits = 8;
            serialPort.Parity = Parity.None; 
            serialPort.StopBits = StopBits.Two; 

            try
            {
                serialPort.Open();
                Message=($"Connect to {selectedPort}\r");
                TerminalMessageDisplay(Message);
                serialPort.DataReceived += SerialPort_DataReceived;

                //讀取NSP
                //DataRcvEvnt.Reset();
                serialPort.WriteLine("DM:E3\r");
                receivedData.TrimEnd('\r', '\n');
                int valueNSP = Convert.ToInt32(receivedData, 16);
                txtNearPos.Text = valueNSP.ToString() ;
                System.Threading.Thread.Sleep(100);
                //DataRcvEvnt.WaitOne();
                //讀取FSP
                serialPort.WriteLine("DM:E1\r");
                receivedData.TrimEnd('\r', '\n');
                int valueFSP = Convert.ToInt32(receivedData, 16);
                txtFarPos.Text = valueFSP.ToString();
                System.Threading.Thread.Sleep(100);
                //讀取Zpos
                serialPort.WriteLine("DP\r");
                receivedData.TrimEnd('\r', '\n');
                int valueDP = Convert.ToInt32(receivedData, 16);
                txtZpos.Text = valueDP.ToString();
                System.Threading.Thread.Sleep(100);

                Task.Run(async() =>
                {
                    while (true)
                    {
                        // 發送命令
                         serialPort.WriteLine("SIG\r");
                        // 等待0.1秒
                         System.Threading.Thread.Sleep(100);
                        // 發送命令
                        serialPort.WriteLine("DP\r");
                        // 等待0.1秒
                        System.Threading.Thread.Sleep(100);

                        if (isPaused)
                        {
                            await taskCompletionSource.Task;
                            taskCompletionSource = new TaskCompletionSource<bool>();
                        }
                    }
                });

            }
            catch (Exception ex)
            {
                Message= ($"Error: {ex.Message}\r");
                TerminalMessageDisplay(Message);
            }

        }

        private void SC0Button_Click(object sender, EventArgs e)
        {
            string command = "SC0";
            if (serialPort != null && serialPort.IsOpen)
            {
                AFCconstantRewriting(FocusingTimes);
                //send SC command
                TerminalMessageDisplay($"Do : {command}\r");
                isPaused = true;
                serialPort.WriteLine(command+"\r");
                isPaused = false;
                taskCompletionSource.SetResult(true);
            }
            else
            {
               Message=("Serial port is not open.\r");
               TerminalMessageDisplay(Message);
               return;
            }
        }

        private void AF0Button_Click(object sender, EventArgs e)
        {
            string command = "AF0";
            if (serialPort != null && serialPort.IsOpen)
            {
                AFCconstantRewriting(FocusingTimes);
                TerminalMessageDisplay($"Do : {command}\r");
                isPaused = true;
                serialPort.WriteLine(command + "\r");
                isPaused = false;
                taskCompletionSource.SetResult(true);
            }
            else
            {
                Message = ("Serial port is not open.\r");
                TerminalMessageDisplay(Message);
                return;
            }

        }

        private void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            // 從串口讀取接收到的數據
            receivedData = serialPort.ReadLine();
            if ((receivedData.Length >= 6) && (receivedData[4] == ','))
            {
                this.BeginInvoke(new EventHandler(sensorVoltageRead));
            }
            else
            {
                this.BeginInvoke(new EventHandler(analyzeSerialPort_Data));
            }
        }

        private void TerminalMessageDisplay(string Message)
        {
            DateTime now = DateTime.Now;
            string formattedTime = now.ToString("yyyy/MM/dd/tt hh:mm:ss");
            txtTerminalData.AppendText($"{formattedTime}>>{Message}\r\n");
            return ;
        }

        private void analyzeSerialPort_Data(object sender, EventArgs e)
        {
            switch (receivedData)
            {
                case "CE\r":
                    Message = ("Command error.");
                    TerminalMessageDisplay(Message);
                    break;

                case "FE\r":
                    Message = ("Far error.");
                    TerminalMessageDisplay(Message);
                    break;

                case "PE\r":
                    Message = ("Peak detect error.");
                    TerminalMessageDisplay(Message);
                    break;

                case "JF\r":
                    Message = ("Detected focus point in moving FAR direction.");
                    TerminalMessageDisplay(Message);
                    break;

                case "JN\r":
                    Message = ("Detected focus point in moving NEAR direction.");
                    TerminalMessageDisplay(Message);
                    break;

                case "J\r":
                    isPaused = true;
                    BarInFocus.Value = 100;
                    break;

                case "K\r":
                    Message = ("Detected focus point in moving NEAR direction.");
                    TerminalMessageDisplay(Message);
                    DataRcvEvnt.Set();
                    break;

                default:
                    if (receivedData.Substring(0,1) == "0")
                    {
                        
                        txtZpos.Text = receivedData.Replace("\r", "").Replace("\n", ""); ;
                    }
                    else
                    {
                        Message = receivedData.Replace("\r", "").Replace("\n", "");
                        TerminalMessageDisplay(Message);
                    }
                    break;
            }
            if (receivedData != "J\r") { BarInFocus.Value = 0; }
        }


        private void sensorVoltageRead(object sender, EventArgs e)
        {
            receivedData.TrimEnd('\r', '\n');
            string[] parts = receivedData.Split(',');
            double Ia = Convert.ToInt32(parts[0], 16) * 4.89;
            double Ib = Convert.ToInt32(parts[1], 16) * 4.89;
            double Sa = Convert.ToInt32(parts[2], 16) * 4.89;
            double Sb = Convert.ToInt32(parts[3], 16) * 4.89;

            txtVoltIa.Text = (Ia/1000).ToString();
            txtVoltIb.Text = (Ib/1000).ToString();
            txtVoltSa.Text = (Sb/1000).ToString();
            txtVoltSb.Text = (Sb/1000).ToString();

            VBarIa.Value = (int)Ia;
            VBarIb.Value = (int)Ib;
            VBarSa.Value = (int)Sa;
            VBarSb.Value = (int)Sb;

        }


        private void AFCconstantRewriting(int FocusingTimes)
        {
            string WMvalue = FocusingTimes.ToString("X2");
            serialPort.WriteLine($"WM{WMvalue}:07AH\r");
            TerminalMessageDisplay("Obtain the permission for writing into EPROM");
            Task.Delay(500);
        }

        private void FocusTimesTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                if (int.TryParse(txtFocusTimes.Text, out FocusingTimes) && FocusingTimes > 0)
                {
                    TerminalMessageDisplay($"執行{FocusingTimes}次對焦功能.\r");
                }
                else
                {
                    TerminalMessageDisplay("請輸入正整數.\r");
                    MessageBox.Show("請輸入正整數", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                serialPort.WriteLine("WON\r");
                Task.Delay(500);
            }
        }

        private void btnsend_Click(object sender, EventArgs e)
        {
            string command = txtCmd.Text+"\r";
            if (serialPort != null && serialPort.IsOpen)
            {
                TerminalMessageDisplay($"Do : {command}\r");
                isPaused = true;
                serialPort.WriteLine(command + "\r");
                isPaused = false;
                taskCompletionSource.SetResult(true);
            }
            else
            {
                Message = ("Serial port is not open.\r");
                TerminalMessageDisplay(Message);
                return;
            }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            string command = "Y";
            if (serialPort != null && serialPort.IsOpen)
            {
                TerminalMessageDisplay("Stop the AF condition\r");
                isPaused = true;
                serialPort.WriteLine(command + "\r");
                isPaused = false;
                taskCompletionSource.SetResult(true);
            }
            else
            {
                Message = ("Serial port is not open.\r");
                TerminalMessageDisplay(Message);
                return;
            }

        }

        private void btnResume_Click(object sender, EventArgs e)
        {
            string command = "Z";
            if (serialPort != null && serialPort.IsOpen)
            {
                TerminalMessageDisplay("Stop the AF condition\r");
                isPaused = true;
                serialPort.WriteLine(command + "\r");
                isPaused = false;
                taskCompletionSource.SetResult(true);
            }
            else
            {
                Message = ("Serial port is not open.\r");
                TerminalMessageDisplay(Message);
                return;
            }
        }

        private void btnTerminate_Click(object sender, EventArgs e)
        {
            string command = "Q";
            if (serialPort != null && serialPort.IsOpen)
            {
                TerminalMessageDisplay("Stop the AF condition\r");
                isPaused = true;
                serialPort.WriteLine(command + "\r");
                isPaused = false;
                taskCompletionSource.SetResult(true);
            }
            else
            {
                Message = ("Serial port is not open.\r");
                TerminalMessageDisplay(Message);
                return;
            }
        }

        private void OnForm1_FormClosing(object sender, FormClosingEventArgs e)
        {
            serialPort.Close();
        }

        private void button1_Click(object sender, EventArgs e)

        {
            isPaused = true;
            System.Threading.Thread.Sleep(1000);
            isPaused = false;
            taskCompletionSource.SetResult(true);
        }

        private void BarInFocus_Click(object sender, EventArgs e)
        {

        }

        private void btnGoFar_Click(object sender, EventArgs e)
        {
            string command = "F:"+txtPulse.Text;
            if (serialPort != null && serialPort.IsOpen)
            {
                TerminalMessageDisplay($"Go Far{txtPulse.Text}\r");
                isPaused = true;
                serialPort.WriteLine(command + "\r");
                isPaused = false;
                taskCompletionSource.SetResult(true);
            }
            else
            {
                Message = ("Serial port is not open.\r");
                TerminalMessageDisplay(Message);
                return;
            }
        }

        private void btnGoNear_Click(object sender, EventArgs e)
        {
            string command = "N:" + txtPulse.Text;
            if (serialPort != null && serialPort.IsOpen)
            {
                TerminalMessageDisplay($"Go Far{txtPulse.Text}\r");
                isPaused = true;
                serialPort.WriteLine(command + "\r");
                isPaused = false;
                taskCompletionSource.SetResult(true);
            }
            else
            {
                Message = ("Serial port is not open.\r");
                TerminalMessageDisplay(Message);
                return;
            }
        }

        private void txtZpos_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtFarPos_TextChanged(object sender, EventArgs e)
        {

        }
    }
}


