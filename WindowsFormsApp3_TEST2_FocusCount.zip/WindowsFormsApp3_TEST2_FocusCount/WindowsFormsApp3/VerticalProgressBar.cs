﻿using System;
using System.Drawing;
using System.Windows.Forms;

public class VerticalProgressBar : ProgressBar
{
    public VerticalProgressBar()
    {
        // 使用自定義繪製
        this.SetStyle(ControlStyles.UserPaint, true);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        // 清除背景
        using (SolidBrush backgroundBrush = new SolidBrush(this.BackColor))
        {
            e.Graphics.FillRectangle(backgroundBrush, this.ClientRectangle);
        }

        // 計算進度條填充高度
        float percent = (float)(this.Value - this.Minimum) / (float)(this.Maximum - this.Minimum);
        int height = (int)(this.Height * percent);

        // 繪製藍色的進度條
        Rectangle rect = new Rectangle(0, this.Height - height, this.Width, height);
        using (SolidBrush brush = new SolidBrush(Color.Blue))
        {
            e.Graphics.FillRectangle(brush, rect);
        }



        // 繪製邊框
        ControlPaint.DrawBorder(e.Graphics, this.ClientRectangle, Color.Black, ButtonBorderStyle.Solid);
    }
}