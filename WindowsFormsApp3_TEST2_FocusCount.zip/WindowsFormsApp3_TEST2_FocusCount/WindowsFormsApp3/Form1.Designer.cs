﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.comboboxComport = new System.Windows.Forms.ComboBox();
            this.btnComportConnect = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnAF0 = new System.Windows.Forms.Button();
            this.btnSC0 = new System.Windows.Forms.Button();
            this.txtTerminalData = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtFocusTimes = new System.Windows.Forms.TextBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.serialPort = new System.IO.Ports.SerialPort(this.components);
            this.btnSend = new System.Windows.Forms.Button();
            this.txtCmd = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnTerminate = new System.Windows.Forms.Button();
            this.btnResume = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.IntegerVolt = new System.Windows.Forms.GroupBox();
            this.txtVoltIb = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtVoltIa = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtVoltSb = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtVoltSa = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SensorVolt = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.BarInFocus = new System.Windows.Forms.ProgressBar();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnGoNear = new System.Windows.Forms.Button();
            this.txtPulse = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnGoFar = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.txtZpos = new System.Windows.Forms.TextBox();
            this.txtNearPos = new System.Windows.Forms.TextBox();
            this.txtFarPos = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.IntegerVolt.SuspendLayout();
            this.SensorVolt.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // comboboxComport
            // 
            this.comboboxComport.FormattingEnabled = true;
            this.comboboxComport.Location = new System.Drawing.Point(12, 36);
            this.comboboxComport.Name = "comboboxComport";
            this.comboboxComport.Size = new System.Drawing.Size(201, 20);
            this.comboboxComport.TabIndex = 0;
            // 
            // btnComportConnect
            // 
            this.btnComportConnect.Location = new System.Drawing.Point(219, 36);
            this.btnComportConnect.Name = "btnComportConnect";
            this.btnComportConnect.Size = new System.Drawing.Size(61, 23);
            this.btnComportConnect.TabIndex = 1;
            this.btnComportConnect.Text = "連線";
            this.btnComportConnect.UseVisualStyleBackColor = true;
            this.btnComportConnect.Click += new System.EventHandler(this.ComportConnectButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnAF0);
            this.groupBox1.Controls.Add(this.btnSC0);
            this.groupBox1.Location = new System.Drawing.Point(16, 145);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(339, 76);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Auto Fcous";
            // 
            // btnAF0
            // 
            this.btnAF0.Location = new System.Drawing.Point(89, 31);
            this.btnAF0.Name = "btnAF0";
            this.btnAF0.Size = new System.Drawing.Size(69, 28);
            this.btnAF0.TabIndex = 1;
            this.btnAF0.Text = "AF0";
            this.btnAF0.UseVisualStyleBackColor = true;
            this.btnAF0.Click += new System.EventHandler(this.AF0Button_Click);
            // 
            // btnSC0
            // 
            this.btnSC0.Location = new System.Drawing.Point(4, 31);
            this.btnSC0.Name = "btnSC0";
            this.btnSC0.Size = new System.Drawing.Size(66, 28);
            this.btnSC0.TabIndex = 0;
            this.btnSC0.Text = "SC0";
            this.btnSC0.UseCompatibleTextRendering = true;
            this.btnSC0.UseVisualStyleBackColor = true;
            this.btnSC0.Click += new System.EventHandler(this.SC0Button_Click);
            // 
            // txtTerminalData
            // 
            this.txtTerminalData.Location = new System.Drawing.Point(865, 120);
            this.txtTerminalData.Multiline = true;
            this.txtTerminalData.Name = "txtTerminalData";
            this.txtTerminalData.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtTerminalData.Size = new System.Drawing.Size(293, 373);
            this.txtTerminalData.TabIndex = 3;
            this.txtTerminalData.WordWrap = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtFocusTimes);
            this.groupBox2.Location = new System.Drawing.Point(12, 90);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(100, 50);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "FocusTimes";
            // 
            // txtFocusTimes
            // 
            this.txtFocusTimes.Location = new System.Drawing.Point(4, 19);
            this.txtFocusTimes.Margin = new System.Windows.Forms.Padding(2);
            this.txtFocusTimes.Name = "txtFocusTimes";
            this.txtFocusTimes.Size = new System.Drawing.Size(76, 22);
            this.txtFocusTimes.TabIndex = 0;
            this.txtFocusTimes.Text = "1";
            this.txtFocusTimes.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.FocusTimesTextBox_KeyPress);
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(1083, 88);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(75, 23);
            this.btnSend.TabIndex = 9;
            this.btnSend.Text = "Send";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnsend_Click);
            // 
            // txtCmd
            // 
            this.txtCmd.Location = new System.Drawing.Point(865, 90);
            this.txtCmd.Name = "txtCmd";
            this.txtCmd.Size = new System.Drawing.Size(212, 22);
            this.txtCmd.TabIndex = 14;
            this.txtCmd.Text = "SC0";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnTerminate);
            this.groupBox3.Controls.Add(this.btnResume);
            this.groupBox3.Controls.Add(this.btnStop);
            this.groupBox3.Location = new System.Drawing.Point(16, 417);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(339, 76);
            this.groupBox3.TabIndex = 15;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Command";
            // 
            // btnTerminate
            // 
            this.btnTerminate.Location = new System.Drawing.Point(180, 31);
            this.btnTerminate.Name = "btnTerminate";
            this.btnTerminate.Size = new System.Drawing.Size(69, 28);
            this.btnTerminate.TabIndex = 2;
            this.btnTerminate.Text = "Terminate";
            this.btnTerminate.UseVisualStyleBackColor = true;
            this.btnTerminate.Click += new System.EventHandler(this.btnTerminate_Click);
            // 
            // btnResume
            // 
            this.btnResume.Location = new System.Drawing.Point(89, 31);
            this.btnResume.Name = "btnResume";
            this.btnResume.Size = new System.Drawing.Size(69, 28);
            this.btnResume.TabIndex = 1;
            this.btnResume.Text = "Resume";
            this.btnResume.UseVisualStyleBackColor = true;
            this.btnResume.Click += new System.EventHandler(this.btnResume_Click);
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(4, 31);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(66, 28);
            this.btnStop.TabIndex = 0;
            this.btnStop.Text = "Stop";
            this.btnStop.UseCompatibleTextRendering = true;
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // IntegerVolt
            // 
            this.IntegerVolt.Controls.Add(this.txtVoltIb);
            this.IntegerVolt.Controls.Add(this.label2);
            this.IntegerVolt.Controls.Add(this.txtVoltIa);
            this.IntegerVolt.Controls.Add(this.label1);
            this.IntegerVolt.Location = new System.Drawing.Point(376, 290);
            this.IntegerVolt.Name = "IntegerVolt";
            this.IntegerVolt.Size = new System.Drawing.Size(380, 203);
            this.IntegerVolt.TabIndex = 16;
            this.IntegerVolt.TabStop = false;
            this.IntegerVolt.Text = "IntegerVolt";
            // 
            // txtVoltIb
            // 
            this.txtVoltIb.Location = new System.Drawing.Point(255, 167);
            this.txtVoltIb.Name = "txtVoltIb";
            this.txtVoltIb.Size = new System.Drawing.Size(100, 22);
            this.txtVoltIb.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 12F);
            this.label2.Location = new System.Drawing.Point(230, 181);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "B";
            // 
            // txtVoltIa
            // 
            this.txtVoltIa.Location = new System.Drawing.Point(49, 167);
            this.txtVoltIa.Name = "txtVoltIa";
            this.txtVoltIa.Size = new System.Drawing.Size(100, 22);
            this.txtVoltIa.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 12F);
            this.label1.Location = new System.Drawing.Point(25, 175);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "A";
            // 
            // txtVoltSb
            // 
            this.txtVoltSb.Location = new System.Drawing.Point(255, 167);
            this.txtVoltSb.Name = "txtVoltSb";
            this.txtVoltSb.Size = new System.Drawing.Size(100, 22);
            this.txtVoltSb.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 12F);
            this.label3.Location = new System.Drawing.Point(230, 173);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "B";
            // 
            // txtVoltSa
            // 
            this.txtVoltSa.Location = new System.Drawing.Point(49, 167);
            this.txtVoltSa.Name = "txtVoltSa";
            this.txtVoltSa.Size = new System.Drawing.Size(100, 22);
            this.txtVoltSa.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("新細明體", 12F);
            this.label4.Location = new System.Drawing.Point(25, 167);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(18, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "A";
            // 
            // SensorVolt
            // 
            this.SensorVolt.Controls.Add(this.txtVoltSb);
            this.SensorVolt.Controls.Add(this.label3);
            this.SensorVolt.Controls.Add(this.txtVoltSa);
            this.SensorVolt.Controls.Add(this.label4);
            this.SensorVolt.Location = new System.Drawing.Point(376, 73);
            this.SensorVolt.Name = "SensorVolt";
            this.SensorVolt.Size = new System.Drawing.Size(380, 196);
            this.SensorVolt.TabIndex = 17;
            this.SensorVolt.TabStop = false;
            this.SensorVolt.Text = "SensorVolt";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(394, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 33);
            this.button1.TabIndex = 18;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // BarInFocus
            // 
            this.BarInFocus.Location = new System.Drawing.Point(128, 111);
            this.BarInFocus.Margin = new System.Windows.Forms.Padding(2);
            this.BarInFocus.Name = "BarInFocus";
            this.BarInFocus.Size = new System.Drawing.Size(75, 28);
            this.BarInFocus.TabIndex = 19;
            this.BarInFocus.Click += new System.EventHandler(this.BarInFocus_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(140, 119);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 12);
            this.label5.TabIndex = 20;
            this.label5.Text = "JustFocus";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnGoNear);
            this.groupBox4.Controls.Add(this.txtPulse);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.btnGoFar);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.txtZpos);
            this.groupBox4.Controls.Add(this.txtNearPos);
            this.groupBox4.Controls.Add(this.txtFarPos);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Location = new System.Drawing.Point(16, 240);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(339, 161);
            this.groupBox4.TabIndex = 21;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "POS";
            // 
            // btnGoNear
            // 
            this.btnGoNear.Location = new System.Drawing.Point(180, 64);
            this.btnGoNear.Name = "btnGoNear";
            this.btnGoNear.Size = new System.Drawing.Size(51, 22);
            this.btnGoNear.TabIndex = 29;
            this.btnGoNear.Text = "GoNear";
            this.btnGoNear.UseCompatibleTextRendering = true;
            this.btnGoNear.UseVisualStyleBackColor = true;
            this.btnGoNear.Click += new System.EventHandler(this.btnGoNear_Click);
            // 
            // txtPulse
            // 
            this.txtPulse.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtPulse.Location = new System.Drawing.Point(38, 64);
            this.txtPulse.Name = "txtPulse";
            this.txtPulse.ShortcutsEnabled = false;
            this.txtPulse.Size = new System.Drawing.Size(41, 22);
            this.txtPulse.TabIndex = 28;
            this.txtPulse.Text = "1";
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("新細明體", 10F);
            this.label9.Location = new System.Drawing.Point(0, 64);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 22);
            this.label9.TabIndex = 27;
            this.label9.Text = "Move";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label9.UseCompatibleTextRendering = true;
            // 
            // btnGoFar
            // 
            this.btnGoFar.Location = new System.Drawing.Point(107, 64);
            this.btnGoFar.Name = "btnGoFar";
            this.btnGoFar.Size = new System.Drawing.Size(51, 22);
            this.btnGoFar.TabIndex = 2;
            this.btnGoFar.Text = "GoFar";
            this.btnGoFar.UseCompatibleTextRendering = true;
            this.btnGoFar.UseVisualStyleBackColor = true;
            this.btnGoFar.Click += new System.EventHandler(this.btnGoFar_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(5, 29);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(28, 17);
            this.label8.TabIndex = 26;
            this.label8.Text = "ZPos";
            this.label8.UseCompatibleTextRendering = true;
            // 
            // txtZpos
            // 
            this.txtZpos.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtZpos.Location = new System.Drawing.Point(38, 24);
            this.txtZpos.Name = "txtZpos";
            this.txtZpos.ReadOnly = true;
            this.txtZpos.ShortcutsEnabled = false;
            this.txtZpos.Size = new System.Drawing.Size(58, 22);
            this.txtZpos.TabIndex = 25;
            this.txtZpos.TextChanged += new System.EventHandler(this.txtZpos_TextChanged);
            // 
            // txtNearPos
            // 
            this.txtNearPos.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtNearPos.Location = new System.Drawing.Point(258, 26);
            this.txtNearPos.Name = "txtNearPos";
            this.txtNearPos.ReadOnly = true;
            this.txtNearPos.ShortcutsEnabled = false;
            this.txtNearPos.Size = new System.Drawing.Size(64, 22);
            this.txtNearPos.TabIndex = 24;
            // 
            // txtFarPos
            // 
            this.txtFarPos.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtFarPos.Location = new System.Drawing.Point(146, 26);
            this.txtFarPos.Name = "txtFarPos";
            this.txtFarPos.ReadOnly = true;
            this.txtFarPos.ShortcutsEnabled = false;
            this.txtFarPos.Size = new System.Drawing.Size(66, 22);
            this.txtFarPos.TabIndex = 4;
            this.txtFarPos.TextChanged += new System.EventHandler(this.txtFarPos_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(217, 29);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 17);
            this.label7.TabIndex = 23;
            this.label7.Text = "NEAR";
            this.label7.UseCompatibleTextRendering = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(112, 29);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 17);
            this.label6.TabIndex = 22;
            this.label6.Text = "FAR";
            this.label6.UseCompatibleTextRendering = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 560);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.BarInFocus);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.SensorVolt);
            this.Controls.Add(this.IntegerVolt);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.txtCmd);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.txtTerminalData);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnComportConnect);
            this.Controls.Add(this.comboboxComport);
            this.Name = "Form1";
            this.Text = "AFC-5";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.IntegerVolt.ResumeLayout(false);
            this.IntegerVolt.PerformLayout();
            this.SensorVolt.ResumeLayout(false);
            this.SensorVolt.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboboxComport;
        private System.Windows.Forms.Button btnComportConnect;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnSC0;
        private System.Windows.Forms.Button btnAF0;
        private System.Windows.Forms.TextBox txtTerminalData;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.TextBox txtFocusTimes;
        private System.IO.Ports.SerialPort serialPort;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.TextBox txtCmd;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnResume;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnTerminate;
        private System.Windows.Forms.GroupBox IntegerVolt;
        private System.Windows.Forms.TextBox txtVoltIa;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtVoltIb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtVoltSb;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtVoltSa;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox SensorVolt;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ProgressBar BarInFocus;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtZpos;
        private System.Windows.Forms.TextBox txtNearPos;
        private System.Windows.Forms.TextBox txtFarPos;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnGoNear;
        private System.Windows.Forms.TextBox txtPulse;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnGoFar;
    }
}

