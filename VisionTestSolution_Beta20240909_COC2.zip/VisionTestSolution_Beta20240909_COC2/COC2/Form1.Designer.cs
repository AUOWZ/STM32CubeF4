﻿namespace COC2
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnLoadImage = new System.Windows.Forms.Button();
            this.btnRun = new System.Windows.Forms.Button();
            this.txtPxSize = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txtFilename = new System.Windows.Forms.TextBox();
            this.dataGridViewDetail = new System.Windows.Forms.DataGridView();
            this.btnSaveImage = new System.Windows.Forms.Button();
            this.cogDisplay1 = new Cognex.VisionPro.Display.CogDisplay();
            this.btnCogImageConvert1 = new System.Windows.Forms.Button();
            this.btnCogPMAlign1 = new System.Windows.Forms.Button();
            this.MarkTraning = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnCogImageConvert2 = new System.Windows.Forms.Button();
            this.btnCogPMAlign2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDetail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cogDisplay1)).BeginInit();
            this.MarkTraning.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnLoadImage
            // 
            this.btnLoadImage.Location = new System.Drawing.Point(32, 33);
            this.btnLoadImage.Name = "btnLoadImage";
            this.btnLoadImage.Size = new System.Drawing.Size(126, 29);
            this.btnLoadImage.TabIndex = 1;
            this.btnLoadImage.Text = "LOAD IMAGE";
            this.btnLoadImage.UseVisualStyleBackColor = true;
            this.btnLoadImage.Click += new System.EventHandler(this.btnLoadImage_Click);
            // 
            // btnRun
            // 
            this.btnRun.Location = new System.Drawing.Point(174, 33);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(126, 29);
            this.btnRun.TabIndex = 2;
            this.btnRun.Text = "RUN";
            this.btnRun.UseVisualStyleBackColor = true;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // txtPxSize
            // 
            this.txtPxSize.Location = new System.Drawing.Point(110, 74);
            this.txtPxSize.Name = "txtPxSize";
            this.txtPxSize.Size = new System.Drawing.Size(191, 22);
            this.txtPxSize.TabIndex = 40;
            this.txtPxSize.Text = "0.25";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(30, 74);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 12);
            this.label4.TabIndex = 39;
            this.label4.Text = "lpixel_size:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(32, 118);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(435, 205);
            this.dataGridView1.TabIndex = 41;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // txtFilename
            // 
            this.txtFilename.Location = new System.Drawing.Point(32, 338);
            this.txtFilename.Name = "txtFilename";
            this.txtFilename.ReadOnly = true;
            this.txtFilename.Size = new System.Drawing.Size(345, 22);
            this.txtFilename.TabIndex = 42;
            // 
            // dataGridViewDetail
            // 
            this.dataGridViewDetail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDetail.Location = new System.Drawing.Point(32, 366);
            this.dataGridViewDetail.Name = "dataGridViewDetail";
            this.dataGridViewDetail.RowTemplate.Height = 24;
            this.dataGridViewDetail.Size = new System.Drawing.Size(435, 249);
            this.dataGridViewDetail.TabIndex = 43;
            this.dataGridViewDetail.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDetail_CellContentClick);
            // 
            // btnSaveImage
            // 
            this.btnSaveImage.Location = new System.Drawing.Point(383, 336);
            this.btnSaveImage.Name = "btnSaveImage";
            this.btnSaveImage.Size = new System.Drawing.Size(84, 22);
            this.btnSaveImage.TabIndex = 44;
            this.btnSaveImage.Text = "Save";
            this.btnSaveImage.UseVisualStyleBackColor = true;
            this.btnSaveImage.Click += new System.EventHandler(this.btnSaveImage_Click);
            // 
            // cogDisplay1
            // 
            this.cogDisplay1.ColorMapLowerClipColor = System.Drawing.Color.Black;
            this.cogDisplay1.ColorMapLowerRoiLimit = 0D;
            this.cogDisplay1.ColorMapPredefined = Cognex.VisionPro.Display.CogDisplayColorMapPredefinedConstants.None;
            this.cogDisplay1.ColorMapUpperClipColor = System.Drawing.Color.Black;
            this.cogDisplay1.ColorMapUpperRoiLimit = 1D;
            this.cogDisplay1.DoubleTapZoomCycleLength = 2;
            this.cogDisplay1.DoubleTapZoomSensitivity = 2.5D;
            this.cogDisplay1.Location = new System.Drawing.Point(742, 118);
            this.cogDisplay1.MouseWheelMode = Cognex.VisionPro.Display.CogDisplayMouseWheelModeConstants.Zoom1;
            this.cogDisplay1.MouseWheelSensitivity = 1D;
            this.cogDisplay1.Name = "cogDisplay1";
            this.cogDisplay1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("cogDisplay1.OcxState")));
            this.cogDisplay1.Size = new System.Drawing.Size(632, 497);
            this.cogDisplay1.TabIndex = 45;
            this.cogDisplay1.Enter += new System.EventHandler(this.cogDisplay1_Enter);
            // 
            // btnCogImageConvert1
            // 
            this.btnCogImageConvert1.Location = new System.Drawing.Point(31, 39);
            this.btnCogImageConvert1.Name = "btnCogImageConvert1";
            this.btnCogImageConvert1.Size = new System.Drawing.Size(126, 29);
            this.btnCogImageConvert1.TabIndex = 49;
            this.btnCogImageConvert1.Text = "CogImageConvert1";
            this.btnCogImageConvert1.UseVisualStyleBackColor = true;
            this.btnCogImageConvert1.Click += new System.EventHandler(this.btnCogImageConvert1_Click);
            // 
            // btnCogPMAlign1
            // 
            this.btnCogPMAlign1.Location = new System.Drawing.Point(31, 97);
            this.btnCogPMAlign1.Name = "btnCogPMAlign1";
            this.btnCogPMAlign1.Size = new System.Drawing.Size(126, 29);
            this.btnCogPMAlign1.TabIndex = 46;
            this.btnCogPMAlign1.Text = "CogPMAlign1";
            this.btnCogPMAlign1.UseVisualStyleBackColor = true;
            this.btnCogPMAlign1.Click += new System.EventHandler(this.btnCogPMAlign1_Click);
            // 
            // MarkTraning
            // 
            this.MarkTraning.Controls.Add(this.btnCogImageConvert1);
            this.MarkTraning.Controls.Add(this.btnCogPMAlign1);
            this.MarkTraning.Location = new System.Drawing.Point(501, 138);
            this.MarkTraning.Name = "MarkTraning";
            this.MarkTraning.Size = new System.Drawing.Size(195, 146);
            this.MarkTraning.TabIndex = 50;
            this.MarkTraning.TabStop = false;
            this.MarkTraning.Text = "MarkTraning";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnCogImageConvert2);
            this.groupBox1.Controls.Add(this.btnCogPMAlign2);
            this.groupBox1.Location = new System.Drawing.Point(501, 311);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(195, 146);
            this.groupBox1.TabIndex = 51;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Led Traning";
            // 
            // btnCogImageConvert2
            // 
            this.btnCogImageConvert2.Location = new System.Drawing.Point(31, 39);
            this.btnCogImageConvert2.Name = "btnCogImageConvert2";
            this.btnCogImageConvert2.Size = new System.Drawing.Size(126, 29);
            this.btnCogImageConvert2.TabIndex = 49;
            this.btnCogImageConvert2.Text = "CogImageConvert2";
            this.btnCogImageConvert2.UseVisualStyleBackColor = true;
            this.btnCogImageConvert2.Click += new System.EventHandler(this.btnCogImageConvert2_Click);
            // 
            // btnCogPMAlign2
            // 
            this.btnCogPMAlign2.Location = new System.Drawing.Point(31, 97);
            this.btnCogPMAlign2.Name = "btnCogPMAlign2";
            this.btnCogPMAlign2.Size = new System.Drawing.Size(126, 29);
            this.btnCogPMAlign2.TabIndex = 46;
            this.btnCogPMAlign2.Text = "CogPMAlign2";
            this.btnCogPMAlign2.UseVisualStyleBackColor = true;
            this.btnCogPMAlign2.Click += new System.EventHandler(this.btnCogPMAlign2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(740, 77);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 12);
            this.label1.TabIndex = 52;
            this.label1.Text = "time";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(652, 715);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.TabIndex = 53;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1435, 826);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.MarkTraning);
            this.Controls.Add(this.cogDisplay1);
            this.Controls.Add(this.btnSaveImage);
            this.Controls.Add(this.dataGridViewDetail);
            this.Controls.Add(this.txtFilename);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txtPxSize);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnRun);
            this.Controls.Add(this.btnLoadImage);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDetail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cogDisplay1)).EndInit();
            this.MarkTraning.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLoadImage;
        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.TextBox txtPxSize;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txtFilename;
        private System.Windows.Forms.DataGridView dataGridViewDetail;
        private System.Windows.Forms.Button btnSaveImage;
        private Cognex.VisionPro.Display.CogDisplay cogDisplay1;
        private System.Windows.Forms.Button btnCogImageConvert1;
        private System.Windows.Forms.Button btnCogPMAlign1;
        private System.Windows.Forms.GroupBox MarkTraning;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnCogImageConvert2;
        private System.Windows.Forms.Button btnCogPMAlign2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

