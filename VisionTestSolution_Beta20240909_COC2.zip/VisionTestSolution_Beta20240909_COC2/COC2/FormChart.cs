﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace COC2
{
    public partial class FormChart : Form
    {
        private List<Coc2DataContent> dataList;
        public FormChart(List<Coc2DataContent> data)
        {
             InitializeComponent();
            dataList = data;
            // 初始化散佈圖
            chart1.ChartAreas.Add(new ChartArea("MainArea"));
            chart1.Series.Add("RGBShiftXSeries");
            chart1.Series["RGBShiftXSeries"].ChartType = SeriesChartType.Point; // 設定為散佈圖

            // 繪製散佈圖
            PlotScatterChart();
        }

        private void PlotScatterChart()
        {
            chart1.Series["RGBShiftXSeries"].Points.Clear(); // 清除之前的點

            var filteredData = dataList.Where(data => data.RGB == "R").ToList();

            // 讀取 DataLIST，從 RGB 提取 R 值，並繪製 R 對應的 ShiftX
            for (int i = 0; i < filteredData.Count; i++)
            {
                double shiftX = filteredData[i].ShiftX*0.125; // 對應的 ShiftX 值
                // 將 ShiftX 繪製到散佈圖中，X 軸使用索引 i
                chart1.Series["RGBShiftXSeries"].Points.AddXY(i + 1, shiftX);
            }
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }
    }
}
