﻿namespace COC2
{
    partial class FormMain
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.btnLoadImage = new System.Windows.Forms.Button();
            this.btnRun = new System.Windows.Forms.Button();
            this.txtPxSize = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txtFilename = new System.Windows.Forms.TextBox();
            this.dataGridViewDetail = new System.Windows.Forms.DataGridView();
            this.btnSaveImage = new System.Windows.Forms.Button();
            this.cogDisplay1 = new Cognex.VisionPro.Display.CogDisplay();
            this.btnCogImageConvert1 = new System.Windows.Forms.Button();
            this.btnCogPMAlign1 = new System.Windows.Forms.Button();
            this.MarkTraning = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnCogImageConvert2 = new System.Windows.Forms.Button();
            this.btnCogPMAlign2 = new System.Windows.Forms.Button();
            this.labelTimeElapsed = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnLoadVpp = new System.Windows.Forms.Button();
            this.btnSaveVpp = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtDesign3Y = new System.Windows.Forms.TextBox();
            this.txtDesign2Y = new System.Windows.Forms.TextBox();
            this.txtDesign3X = new System.Windows.Forms.TextBox();
            this.txtDesign2X = new System.Windows.Forms.TextBox();
            this.txtDesign1Y = new System.Windows.Forms.TextBox();
            this.txtDesign1X = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDetail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cogDisplay1)).BeginInit();
            this.MarkTraning.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnLoadImage
            // 
            this.btnLoadImage.Location = new System.Drawing.Point(32, 33);
            this.btnLoadImage.Name = "btnLoadImage";
            this.btnLoadImage.Size = new System.Drawing.Size(126, 29);
            this.btnLoadImage.TabIndex = 1;
            this.btnLoadImage.Text = "LOAD IMAGE";
            this.btnLoadImage.UseVisualStyleBackColor = true;
            this.btnLoadImage.Click += new System.EventHandler(this.btnLoadImage_Click);
            // 
            // btnRun
            // 
            this.btnRun.Location = new System.Drawing.Point(174, 33);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(126, 29);
            this.btnRun.TabIndex = 2;
            this.btnRun.Text = "RUN";
            this.btnRun.UseVisualStyleBackColor = true;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // txtPxSize
            // 
            this.txtPxSize.Location = new System.Drawing.Point(110, 74);
            this.txtPxSize.Name = "txtPxSize";
            this.txtPxSize.Size = new System.Drawing.Size(191, 22);
            this.txtPxSize.TabIndex = 40;
            this.txtPxSize.Text = "0.125";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(30, 74);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 12);
            this.label4.TabIndex = 39;
            this.label4.Text = "lpixel_size:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(32, 118);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(435, 205);
            this.dataGridView1.TabIndex = 41;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // txtFilename
            // 
            this.txtFilename.Location = new System.Drawing.Point(32, 338);
            this.txtFilename.Name = "txtFilename";
            this.txtFilename.ReadOnly = true;
            this.txtFilename.Size = new System.Drawing.Size(345, 22);
            this.txtFilename.TabIndex = 42;
            // 
            // dataGridViewDetail
            // 
            this.dataGridViewDetail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDetail.Location = new System.Drawing.Point(32, 366);
            this.dataGridViewDetail.Name = "dataGridViewDetail";
            this.dataGridViewDetail.RowTemplate.Height = 24;
            this.dataGridViewDetail.Size = new System.Drawing.Size(435, 249);
            this.dataGridViewDetail.TabIndex = 43;
            this.dataGridViewDetail.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDetail_CellContentClick);
            // 
            // btnSaveImage
            // 
            this.btnSaveImage.Location = new System.Drawing.Point(383, 336);
            this.btnSaveImage.Name = "btnSaveImage";
            this.btnSaveImage.Size = new System.Drawing.Size(84, 22);
            this.btnSaveImage.TabIndex = 44;
            this.btnSaveImage.Text = "Save";
            this.btnSaveImage.UseVisualStyleBackColor = true;
            this.btnSaveImage.Click += new System.EventHandler(this.btnSaveImage_Click);
            // 
            // cogDisplay1
            // 
            this.cogDisplay1.ColorMapLowerClipColor = System.Drawing.Color.Black;
            this.cogDisplay1.ColorMapLowerRoiLimit = 0D;
            this.cogDisplay1.ColorMapPredefined = Cognex.VisionPro.Display.CogDisplayColorMapPredefinedConstants.None;
            this.cogDisplay1.ColorMapUpperClipColor = System.Drawing.Color.Black;
            this.cogDisplay1.ColorMapUpperRoiLimit = 1D;
            this.cogDisplay1.DoubleTapZoomCycleLength = 2;
            this.cogDisplay1.DoubleTapZoomSensitivity = 2.5D;
            this.cogDisplay1.Location = new System.Drawing.Point(742, 99);
            this.cogDisplay1.MouseWheelMode = Cognex.VisionPro.Display.CogDisplayMouseWheelModeConstants.Zoom1;
            this.cogDisplay1.MouseWheelSensitivity = 1D;
            this.cogDisplay1.Name = "cogDisplay1";
            this.cogDisplay1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("cogDisplay1.OcxState")));
            this.cogDisplay1.Size = new System.Drawing.Size(547, 378);
            this.cogDisplay1.TabIndex = 45;
            this.cogDisplay1.Enter += new System.EventHandler(this.cogDisplay1_Enter);
            // 
            // btnCogImageConvert1
            // 
            this.btnCogImageConvert1.Location = new System.Drawing.Point(31, 39);
            this.btnCogImageConvert1.Name = "btnCogImageConvert1";
            this.btnCogImageConvert1.Size = new System.Drawing.Size(126, 29);
            this.btnCogImageConvert1.TabIndex = 49;
            this.btnCogImageConvert1.Text = "CogImageConvert1";
            this.btnCogImageConvert1.UseVisualStyleBackColor = true;
            this.btnCogImageConvert1.Click += new System.EventHandler(this.btnCogImageConvert1_Click);
            // 
            // btnCogPMAlign1
            // 
            this.btnCogPMAlign1.Location = new System.Drawing.Point(31, 97);
            this.btnCogPMAlign1.Name = "btnCogPMAlign1";
            this.btnCogPMAlign1.Size = new System.Drawing.Size(126, 29);
            this.btnCogPMAlign1.TabIndex = 46;
            this.btnCogPMAlign1.Text = "CogPMAlign1";
            this.btnCogPMAlign1.UseVisualStyleBackColor = true;
            this.btnCogPMAlign1.Click += new System.EventHandler(this.btnCogPMAlign1_Click);
            // 
            // MarkTraning
            // 
            this.MarkTraning.Controls.Add(this.btnCogImageConvert1);
            this.MarkTraning.Controls.Add(this.btnCogPMAlign1);
            this.MarkTraning.Location = new System.Drawing.Point(501, 138);
            this.MarkTraning.Name = "MarkTraning";
            this.MarkTraning.Size = new System.Drawing.Size(195, 146);
            this.MarkTraning.TabIndex = 50;
            this.MarkTraning.TabStop = false;
            this.MarkTraning.Text = "MarkTraning";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnCogImageConvert2);
            this.groupBox1.Controls.Add(this.btnCogPMAlign2);
            this.groupBox1.Location = new System.Drawing.Point(501, 311);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(195, 146);
            this.groupBox1.TabIndex = 51;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Led Traning";
            // 
            // btnCogImageConvert2
            // 
            this.btnCogImageConvert2.Location = new System.Drawing.Point(31, 39);
            this.btnCogImageConvert2.Name = "btnCogImageConvert2";
            this.btnCogImageConvert2.Size = new System.Drawing.Size(126, 29);
            this.btnCogImageConvert2.TabIndex = 49;
            this.btnCogImageConvert2.Text = "CogImageConvert2";
            this.btnCogImageConvert2.UseVisualStyleBackColor = true;
            this.btnCogImageConvert2.Click += new System.EventHandler(this.btnCogImageConvert2_Click);
            // 
            // btnCogPMAlign2
            // 
            this.btnCogPMAlign2.Location = new System.Drawing.Point(31, 97);
            this.btnCogPMAlign2.Name = "btnCogPMAlign2";
            this.btnCogPMAlign2.Size = new System.Drawing.Size(126, 29);
            this.btnCogPMAlign2.TabIndex = 46;
            this.btnCogPMAlign2.Text = "CogPMAlign2";
            this.btnCogPMAlign2.UseVisualStyleBackColor = true;
            this.btnCogPMAlign2.Click += new System.EventHandler(this.btnCogPMAlign2_Click);
            // 
            // labelTimeElapsed
            // 
            this.labelTimeElapsed.AutoSize = true;
            this.labelTimeElapsed.Location = new System.Drawing.Point(740, 84);
            this.labelTimeElapsed.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelTimeElapsed.Name = "labelTimeElapsed";
            this.labelTimeElapsed.Size = new System.Drawing.Size(25, 12);
            this.labelTimeElapsed.TabIndex = 52;
            this.labelTimeElapsed.Text = "time";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(1139, 588);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(179, 86);
            this.pictureBox1.TabIndex = 53;
            this.pictureBox1.TabStop = false;
            // 
            // btnLoadVpp
            // 
            this.btnLoadVpp.Location = new System.Drawing.Point(341, 33);
            this.btnLoadVpp.Name = "btnLoadVpp";
            this.btnLoadVpp.Size = new System.Drawing.Size(126, 29);
            this.btnLoadVpp.TabIndex = 54;
            this.btnLoadVpp.Text = "LOAD VPP";
            this.btnLoadVpp.UseVisualStyleBackColor = true;
            this.btnLoadVpp.Click += new System.EventHandler(this.btnLoadVpp_Click);
            // 
            // btnSaveVpp
            // 
            this.btnSaveVpp.Location = new System.Drawing.Point(501, 33);
            this.btnSaveVpp.Name = "btnSaveVpp";
            this.btnSaveVpp.Size = new System.Drawing.Size(126, 29);
            this.btnSaveVpp.TabIndex = 55;
            this.btnSaveVpp.Text = "SAVE VPP";
            this.btnSaveVpp.UseVisualStyleBackColor = true;
            this.btnSaveVpp.Click += new System.EventHandler(this.btnSaveVpp_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtDesign3Y);
            this.groupBox2.Controls.Add(this.txtDesign2Y);
            this.groupBox2.Controls.Add(this.txtDesign3X);
            this.groupBox2.Controls.Add(this.txtDesign2X);
            this.groupBox2.Controls.Add(this.txtDesign1Y);
            this.groupBox2.Controls.Add(this.txtDesign1X);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(32, 635);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(435, 213);
            this.groupBox2.TabIndex = 56;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Design(um)";
            // 
            // txtDesign3Y
            // 
            this.txtDesign3Y.Location = new System.Drawing.Point(259, 137);
            this.txtDesign3Y.Name = "txtDesign3Y";
            this.txtDesign3Y.Size = new System.Drawing.Size(49, 22);
            this.txtDesign3Y.TabIndex = 63;
            this.txtDesign3Y.Text = "320";
            // 
            // txtDesign2Y
            // 
            this.txtDesign2Y.Location = new System.Drawing.Point(164, 137);
            this.txtDesign2Y.Name = "txtDesign2Y";
            this.txtDesign2Y.Size = new System.Drawing.Size(49, 22);
            this.txtDesign2Y.TabIndex = 62;
            this.txtDesign2Y.Text = "320";
            // 
            // txtDesign3X
            // 
            this.txtDesign3X.Location = new System.Drawing.Point(259, 78);
            this.txtDesign3X.Name = "txtDesign3X";
            this.txtDesign3X.Size = new System.Drawing.Size(49, 22);
            this.txtDesign3X.TabIndex = 61;
            this.txtDesign3X.Text = "-460.5";
            // 
            // txtDesign2X
            // 
            this.txtDesign2X.Location = new System.Drawing.Point(164, 78);
            this.txtDesign2X.Name = "txtDesign2X";
            this.txtDesign2X.Size = new System.Drawing.Size(49, 22);
            this.txtDesign2X.TabIndex = 59;
            this.txtDesign2X.Text = "-347.7";
            this.txtDesign2X.TextChanged += new System.EventHandler(this.txtDesign2X_TextChanged);
            // 
            // txtDesign1Y
            // 
            this.txtDesign1Y.Location = new System.Drawing.Point(77, 137);
            this.txtDesign1Y.Name = "txtDesign1Y";
            this.txtDesign1Y.Size = new System.Drawing.Size(49, 22);
            this.txtDesign1Y.TabIndex = 58;
            this.txtDesign1Y.Text = "320";
            this.txtDesign1Y.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // txtDesign1X
            // 
            this.txtDesign1X.Location = new System.Drawing.Point(77, 78);
            this.txtDesign1X.Name = "txtDesign1X";
            this.txtDesign1X.Size = new System.Drawing.Size(49, 22);
            this.txtDesign1X.TabIndex = 57;
            this.txtDesign1X.Text = "-234.9";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 12F);
            this.label3.Location = new System.Drawing.Point(86, 32);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(222, 16);
            this.label3.TabIndex = 42;
            this.label3.Text = "R                      G                        B";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 12F);
            this.label2.Location = new System.Drawing.Point(15, 143);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(18, 16);
            this.label2.TabIndex = 41;
            this.label2.Text = "Y";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 12F);
            this.label1.Location = new System.Drawing.Point(15, 78);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 16);
            this.label1.TabIndex = 40;
            this.label1.Text = "X";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(514, 514);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(164, 29);
            this.button1.TabIndex = 57;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(514, 569);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(164, 29);
            this.button2.TabIndex = 58;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1435, 875);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnSaveVpp);
            this.Controls.Add(this.btnLoadVpp);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.labelTimeElapsed);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.MarkTraning);
            this.Controls.Add(this.cogDisplay1);
            this.Controls.Add(this.btnSaveImage);
            this.Controls.Add(this.dataGridViewDetail);
            this.Controls.Add(this.txtFilename);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txtPxSize);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnRun);
            this.Controls.Add(this.btnLoadImage);
            this.Name = "FormMain";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDetail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cogDisplay1)).EndInit();
            this.MarkTraning.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLoadImage;
        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.TextBox txtPxSize;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txtFilename;
        private System.Windows.Forms.DataGridView dataGridViewDetail;
        private System.Windows.Forms.Button btnSaveImage;
        private Cognex.VisionPro.Display.CogDisplay cogDisplay1;
        private System.Windows.Forms.Button btnCogImageConvert1;
        private System.Windows.Forms.Button btnCogPMAlign1;
        private System.Windows.Forms.GroupBox MarkTraning;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnCogImageConvert2;
        private System.Windows.Forms.Button btnCogPMAlign2;
        private System.Windows.Forms.Label labelTimeElapsed;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnLoadVpp;
        private System.Windows.Forms.Button btnSaveVpp;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtDesign3X;
        private System.Windows.Forms.TextBox txtDesign2X;
        private System.Windows.Forms.TextBox txtDesign1Y;
        private System.Windows.Forms.TextBox txtDesign1X;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDesign3Y;
        private System.Windows.Forms.TextBox txtDesign2Y;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}

