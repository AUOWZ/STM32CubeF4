﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COC2
{
    public class Coc2DataContent
    {
        public string FileName { get; set; }
        public string RGB { get; set; }
        public double MarkX { get; set; }
        public double MarkY { get; set; }
        public double LedX { get; set; }
        public double LedY { get; set; }
        public double ShiftX { get; set; }
        public double ShiftY { get; set; }


        public Coc2DataContent(string fileName, string rgb, double markx, double marky, double ledx, double ledy, double shiftx, double shifty)
        {
            FileName = fileName;
            RGB = rgb;
            MarkX = markx;
            MarkY = marky;
            LedX = ledx;
            LedY = ledy;
            ShiftX = shiftx;
            ShiftY = shifty;

        }
    }
}
