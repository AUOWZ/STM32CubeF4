﻿using Cognex.VisionPro;
using Cognex.VisionPro.Blob;
using Cognex.VisionPro.ImageProcessing;
using Cognex.VisionPro.PMAlign;
using Cognex.VisionPro.QuickBuild;
using Cognex.VisionPro.ToolGroup;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace COC2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            //dataGridView1
            dataGridView1.ColumnCount = 2;
            dataGridView1.Columns[0].Name = "Filename";
            dataGridView1.Columns[1].Name = "Path";

            //dataGridViewDetail
            dataGridViewDetail.ColumnCount = 3;
            dataGridViewDetail.Columns[0].Name = "RGB";
            dataGridViewDetail.Columns[1].Name = "Shiftx";
            dataGridViewDetail.Columns[2].Name = "Shifty";


            string vpppath = @"D:\維智\cognex\0828\coc2_pmalign.vpp";
            CogJob job = VisionTool.Method.LoadVisionTool<CogJob>(vpppath);
            this.cogDisplay1.MouseDown += new MouseEventHandler(this.cogDisplay1_MouseDown);
            pictureBox1.MouseClick += new MouseEventHandler(PictureBox1_MouseClick);

            if (job != null)
            {
                CogJob = job;
                CogTools = (job.VisionTool as CogToolGroup).Tools;
            }
            else
            {
                MessageBox.Show("fail load vpp");
                Environment.Exit(0);
            }

        }
        CogJob CogJob { get; set; }
        CogToolCollection CogTools { get; set; }
        string[] filepaths;
        string lastRectangleID = null;
        private List<Coc2DataContent> dataList = new List<Coc2DataContent>();


        //按鈕事件
        private void btnLoadImage_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            cogDisplay1.InteractiveGraphics.Clear();
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Multiselect = true;
            dialog.Title = "請選擇檔案";
            dialog.Filter = "所有檔案(*.*)|*.*";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                // 取得所有選取的檔案完整路徑
                filepaths = dialog.FileNames;
            }

            foreach (string fileName in dialog.FileNames)
            {
                string filePath = System.IO.Path.GetFullPath(fileName);
                string fileNameOnly = System.IO.Path.GetFileName(fileName);

                // 將檔案名稱和路徑加入到 DataGridView 中
                dataGridView1.Rows.Add(fileNameOnly, filePath);
            }
        }

        private async void btnRun_Click(object sender, EventArgs e)
        {
            cogDisplay1.InteractiveGraphics.Clear();
            dataGridViewDetail.Rows.Clear();
            dataList.Clear();
            (sender as Control).BackColor = Color.Yellow;
            (sender as Control).Enabled = false;
            List<(string, Bitmap)> images = new List<(string, Bitmap)>();

            int counts = 10;

            for (int i = 0; i < filepaths.Count(); i += counts)
            {
                var subfilepaths = filepaths.Skip(i).Take(counts);

                foreach (var str in subfilepaths)
                {
                    images.Add((str, (Bitmap)Bitmap.FromFile(str)));
                }


                var vv = await Coc2Process(images.ToArray());

                if (vv.Item1)
                {
                    //title
                    foreach (var rr in vv.Item2)
                    {
                        Coc2Result result = rr;
                        int rgbIndex = 0; // 初始化RGB索引
                        foreach (var led in result.ResultData.Keys)
                        {
                            foreach (var data in result.ResultData[led])
                            {
                                string currentRgb = GetRgbOrder(rgbIndex);
                                double MarkX = data.Item1;
                                double MarkY = data.Item2;
                                double LedX = data.Item3;
                                double LedY = data.Item4;
                                double ShiftX = data.Item5;
                                double ShiftY = data.Item6;

                                // fpr CSV
                                string str = rr.filename + "," + currentRgb + "," + MarkX + "," + MarkY + "," + LedX + "," + LedY + "," + ShiftX + "," + ShiftY;
                                string[] parts = str.ToString().Split(',');

                                var dataContent = new Coc2DataContent(
                                    parts[0], // FileName
                                    parts[1], // RGB
                                    double.Parse(parts[2]), // MarkX
                                    double.Parse(parts[3]), // MarkY
                                    double.Parse(parts[4]), // LedX
                                    double.Parse(parts[5]), // LedY
                                    double.Parse(parts[6]), // ShiftX
                                    double.Parse(parts[7])  // ShiftY
                                    );

                                dataList.Add(dataContent);
                                rgbIndex++; // 更新RGB索引
                            }
                        }
                    }
                }
            }
            MultiplyValuesAndSaveToCsv();
            (sender as Control).BackColor = DefaultBackColor;
            (sender as Control).Enabled = true;
        }

        //運算事件
        TaskCompletionSource<bool> JobStop = new TaskCompletionSource<bool>();
        async Task<(bool, Coc2Result[])> Coc2Process((string, Bitmap)[] ImageData)
        {
            JobStop = new TaskCompletionSource<bool>();

            return await Task.Run(() => 
            {
                List<Coc2Result> ResultList = new List<Coc2Result>();
                foreach (var data in ImageData)
                {
                    if (!JobStop.Task.Wait(0)) 
                    {
                        CogImage24PlanarColor image = new CogImage24PlanarColor(data.Item2);

                        var v = Coc2DoProcess(image);

                        if (v.Item1)
                        {
                            Coc2Result result = new Coc2Result();
                            result.filename = data.Item1;
                            result.ResultData = v.Item3;
                            ResultList.Add(result);
                        }
                    }
                    else
                    {
                        return (false, ResultList.ToArray());
                    }
                }
                return (true, ResultList.ToArray());
            });
        }

        (bool, int, Dictionary<int, List<(double, double, double, double, double, double)>>) Coc2DoProcess(CogImage24PlanarColor image)
        {
            var ImageConvert1 = CogTools["CogImageConvertTool1"] as CogImageConvertTool;
            var PMAlign1 = CogTools["CogPMAlignTool1"] as CogPMAlignTool ;
            var ImageConvert2 = CogTools["CogImageConvertTool2"] as CogImageConvertTool;
            var PMAlign2 = CogTools["CogPMAlignTool2"] as CogPMAlignTool;
            Dictionary<int, List<(double, double, double, double, double, double)>> shiftresult = new Dictionary<int, List<(double, double, double, double, double, double)>>();

            // Search mark
            ImageConvert1.InputImage = image;
            ImageConvert1.Run();

            PMAlign1.InputImage = ImageConvert1.OutputImage;
            PMAlign1.Run();

            if (PMAlign1.RunStatus.Result != CogToolResultConstants.Accept)
                return (false, CogTools.IndexOf(PMAlign1), null);

            if (PMAlign1.Results.Count <= 0)
                return (false, CogTools.IndexOf(PMAlign1), null);

            double MarkX = PMAlign1.Results[0].GetPose().TranslationX;
            double MarkY = PMAlign1.Results[0].GetPose().TranslationY;

            //Search Led
            ImageConvert2.InputImage = image;
            ImageConvert2.Run();

            List<(double X, double Y)> coordinates = new List<(double, double)>
            {
                (2500, 3000),
                (3200, 3000),
                (3900, 3000)
            };

            PMAlign2.InputImage= ImageConvert2.OutputImage;
            int LedIndex = 0;

            PMAlign2.Run();

            var results2 = PMAlign2.Results;
            List<CogPMAlignResult> resultlist = new List<CogPMAlignResult>();
            foreach (CogPMAlignResult r in results2)
            resultlist.Add(r);
            resultlist = resultlist.OrderBy(r => r.GetPose().TranslationX).ToList();

            foreach (CogPMAlignResult ledResult in resultlist)
            {
                shiftresult[++LedIndex] = new List<(double, double, double, double, double, double)>();
                var ledX = ledResult.GetPose().TranslationX;
                var ledY = ledResult.GetPose().TranslationY;

                var ShiftX = ledX - MarkX;
                var ShiftY = ledY - MarkY;

                shiftresult[LedIndex].Add((MarkX, MarkY, ledX, ledY, ShiftX, ShiftY));
            }

            return (true, -1, shiftresult);
        }

        private void MultiplyValuesAndSaveToCsv()
        {
            // 從 TextBox 中取得倍數
            double PxSize = double.Parse(txtPxSize.Text);

            // 指定 CSV 檔案存放路徑 (可根據需求自訂)
            string csv = @"..\ShiftResult_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".csv";

            // 寫入 CSV 檔案
            using (StreamWriter sw = new StreamWriter(csv))
            {
                sw.WriteLine("Filename,RGB,MarkX,MarkY,LedX,LedY,ShiftX,ShiftY");
                // 乘法操作
                foreach (var data in dataList)
                {
                    double MaskX2um = data.MarkX * PxSize;
                    double MaskY2um = data.MarkY * PxSize;
                    double LedX2um = data.LedX* PxSize;
                    double LedY2um = data.LedY * PxSize;
                    double ShiftX2um = data.ShiftX * PxSize;
                    double ShiftY2um = data.ShiftY * PxSize;

                    sw.WriteLine($"{data.FileName},{data.RGB},{MaskX2um},{MaskY2um},{LedX2um},{LedY2um},{ShiftX2um},{ShiftY2um}");
                }
            }
        }

        class Coc2Result
        {
            public string filename;
            public Dictionary<int, List<(double, double, double, double, double, double)>> ResultData = new Dictionary<int, List<(double, double, double, double, double, double)>>();
        }

        public string GetRgbOrder(int index)
        {
            string[] order = { "R", "G", "B" };
            return order[index % 3];
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                // 清除所有舊的圖形標記
                cogDisplay1.InteractiveGraphics.Clear();
                dataGridViewDetail.Rows.Clear();
                // 獲取選中行的檔案路徑
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                string filePath = row.Cells[1].Value.ToString();
                //讀取DataContect
                var points = dataList.Where(entry => entry.FileName == filePath).ToList();

                // 顯示圖片
                Bitmap bmp = new Bitmap(Image.FromFile(filePath));
                Cognex.VisionPro.CogImage24PlanarColor image = new Cognex.VisionPro.CogImage24PlanarColor((Bitmap)bmp);
                cogDisplay1.AutoFit = true;
                cogDisplay1.Image = image;
                txtFilename.Text = filePath;

                foreach (var point in points)
                {
                    double c = point.ShiftX;

                    if (c != -999)
                    {
                        double width2 = 320;
                        double heigth2 = 175;

                        //LED 方形
                        CogRectangle LedSquare = new CogRectangle();
                        LedSquare.X = point.LedX - width2 / 2;
                        LedSquare.Y = point.LedY - heigth2 / 2;
                        LedSquare.Width = width2;
                        LedSquare.Height = heigth2;
                        LedSquare.Color = CogColorConstants.Blue;
                        LedSquare.LineWidthInScreenPixels = 5;
                        //cogDisplay1.InteractiveGraphics.Add(LedSquare, "", false);

                        // LED 十字
                        CogPointMarker LedCrossPoint = new CogPointMarker();
                        LedCrossPoint.X = point.LedX;
                        LedCrossPoint.Y = point.LedY;
                        LedCrossPoint.Color = CogColorConstants.Blue;
                        LedCrossPoint.LineStyle = CogGraphicLineStyleConstants.Solid;
                        LedCrossPoint.LineWidthInScreenPixels = 5;
                        LedCrossPoint.SizeInScreenPixels = 20;
                        cogDisplay1.InteractiveGraphics.Add(LedCrossPoint, "", false);

                        double PxSize = double.Parse(txtPxSize.Text);
                        double Shiftx2um = point.ShiftX * PxSize;
                        double Shifty2um = point.ShiftY * PxSize;
                        // 將篩選後的列表綁定到第二個 GridView
                        dataGridViewDetail.Rows.Add(point.RGB, Shiftx2um, Shifty2um);
                    }
                    else
                    {
                        dataGridViewDetail.Rows.Add(point.RGB, point.ShiftX, point.ShiftY);

                    }
                }
            }
        }

        private void dataGridViewDetail_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                if (lastRectangleID != null)
                {
                    cogDisplay1.InteractiveGraphics.Remove(lastRectangleID);
                    lastRectangleID = null;
                }

                string rgb = dataGridViewDetail.Rows[e.RowIndex].Cells["RGB"].Value.ToString();
                var pointCC = dataList.FirstOrDefault(d => d.FileName == txtFilename.Text && d.RGB == rgb);
                double c = pointCC.ShiftX;

                if (c != -999)
                {
                    double pnxCC = pointCC.LedX;
                    double pnyCC = pointCC.LedY;
                    double width2 = 320;
                    double heigth2 = 175;

                    CogRectangle PnxSquare = new CogRectangle();
                    PnxSquare.X = pnxCC - width2 / 2;
                    PnxSquare.Y = pnyCC - heigth2 / 2;
                    PnxSquare.Width = width2;
                    PnxSquare.Height = heigth2;
                    PnxSquare.Color = CogColorConstants.Green;
                    PnxSquare.LineWidthInScreenPixels = 10;
                    lastRectangleID = "retangle_" + Guid.NewGuid().ToString();
                    //cogDisplay1.InteractiveGraphics.Add(PnxSquare, lastRectangleID, false);
                }
            }
        }

        private void btnCogImageConvert1_Click(object sender, EventArgs e)
        {
            var tool = CogTools["CogImageConvertTool1"];
            VisionTool.FormConvert f = new VisionTool.FormConvert((CogImageConvertTool)tool);
            tool.Changed += Tool_Changed;

            f.ShowDialog();
            f.Dispose();
        }

        private void btnCogPMAlign1_Click(object sender, EventArgs e)
        {
            var tool = CogTools["CogPMAlignTool1"];
            VisionTool.FormPMAlign f = new VisionTool.FormPMAlign((CogPMAlignTool)tool);
            tool.Changed += Tool_Changed;

            f.ShowDialog();
            f.Dispose();

        }

        private void btnCogImageConvert2_Click(object sender, EventArgs e)
        {
            var tool = CogTools["CogImageConvertTool2"];
            VisionTool.FormConvert f = new VisionTool.FormConvert((CogImageConvertTool)tool);
            tool.Changed += Tool_Changed;

            f.ShowDialog();
            f.Dispose();
        }

        private void btnCogPMAlign2_Click(object sender, EventArgs e)
        {
            var tool = CogTools["CogPMAlignTool2"];
            VisionTool.FormPMAlign f = new VisionTool.FormPMAlign((CogPMAlignTool)tool);
            f.ShowDialog();
            f.Dispose();
        }

        private void Tool_Changed(object sender, CogChangedEventArgs e)
        {
            Console.WriteLine("sdf");
        }

        private void cogDisplay1_Enter(object sender, EventArgs e)
        {

        }

        private void cogDisplay1_MouseDown(object sender, MouseEventArgs e)
        {
            // 確保 cogDisplay1 中有已加載的圖像
            if (cogDisplay1.Image == null) return;

            // 取得顯示區域的點擊位置（單位為像素）
            double clickX = e.X;
            double clickY = e.Y;

            // 使用 CogDisplay 的 CoordinateSpaceMapper 來將顯示座標轉換為圖像上的像素座標
            double imageX, imageY;

            // 獲取顯示空間到圖像空間的轉換
            ICogTransform2D displayToImageTransform = cogDisplay1.GetTransform("#", "@");

            if (displayToImageTransform != null)
            {
                // 將顯示區域的點擊座標 (clickX, clickY) 轉換為圖像的像素座標 (imageX, imageY)
                displayToImageTransform.MapPoint(clickX, clickY, out imageX, out imageY);

                // 顯示轉換後的圖像像素座標
                MessageBox.Show($"圖像像素座標: X = {imageX}, Y = {imageY}");
            }
        }

        private void btnSaveImage_Click(object sender, EventArgs e)
        {
            //using (OpenFileDialog openFileDialog = new OpenFileDialog())
            //{
            //    openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";

            //    if (openFileDialog.ShowDialog() == DialogResult.OK)
            //    {
            //        // 載入圖片到 PictureBox
            //        pictureBox1.Image = Image.FromFile(openFileDialog.FileName);
            //    }
            //}
        }
        private void PictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            if (pictureBox1.Image == null) return;

            // PictureBox 大小
            int pbWidth = pictureBox1.Width;
            int pbHeight = pictureBox1.Height;

            // 圖片原始大小
            int imgWidth = pictureBox1.Image.Width;
            int imgHeight = pictureBox1.Image.Height;

            // 計算縮放比例
            float ratioWidth = (float)imgWidth / pbWidth;
            float ratioHeight = (float)imgHeight / pbHeight;
            float ratio = Math.Max(ratioWidth, ratioHeight);

            // 計算顯示圖片的實際大小
            int displayedImageWidth = (int)(imgWidth / ratio);
            int displayedImageHeight = (int)(imgHeight / ratio);

            // 計算圖片在 PictureBox 中的偏移量
            int offsetX = (pbWidth - displayedImageWidth) / 2;
            int offsetY = (pbHeight - displayedImageHeight) / 2;

            // 檢查點擊是否在圖片範圍內
            if (e.X < offsetX || e.X > offsetX + displayedImageWidth || e.Y < offsetY || e.Y > offsetY + displayedImageHeight)
            {
                MessageBox.Show("點擊不在圖片範圍內");
                return;
            }

            // 計算圖片上的實際座標
            int imageX = (int)((e.X - offsetX) * ratio);
            int imageY = (int)((e.Y - offsetY) * ratio);

            // 顯示圖片上的座標
            MessageBox.Show($"圖片座標: X = {imageX}, Y = {imageY}");
        }
    }
}
