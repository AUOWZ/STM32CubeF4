﻿using Cognex.VisionPro;
using Cognex.VisionPro.Blob;
using Cognex.VisionPro.Display;
using Cognex.VisionPro.ImageProcessing;
using Cognex.VisionPro.PMAlign;
using Cognex.VisionPro.QuickBuild;
using Cognex.VisionPro.ResultsAnalysis;
using Cognex.VisionPro.ToolGroup;
using QWhale.Editor.TextSource;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Markup;
using System.Windows.Media.Imaging;
using System.Windows.Media.TextFormatting;
using System.Windows.Shapes;
using MessageBox = System.Windows.MessageBox;
using Path = System.IO.Path;

namespace VisionTest_01
{

    public partial class FormMain : Form
    {

        private List<DataContent> dataList = new List<DataContent>();
        string shiftcsv;
        string lastRectangleID = null;
        List<string> DataResult = new List<string>();
        public FormMain()
        {
            InitializeComponent();

            ThreadPool.SetMinThreads(3000, 3000);
            ThreadPool.GetMaxThreads(out int a, out int b);
            ThreadPool.SetMaxThreads(a, 3000);

            dataGridView1.ColumnCount = 2;
            dataGridView1.Columns[0].Name = "Filename";
            dataGridView1.Columns[1].Name = "Path";
            dataGridView1.CellClick += dataGridView1_CellClick;

            //dataGridViewDetail
            dataGridViewDetail.CellClick += dataGridViewDetail_CellClick;
            dataGridViewDetail.CellFormatting += dataGridViewDetail_CellFormatting; 
            dataGridViewDetail.ColumnCount = 4;
            dataGridViewDetail.Columns[0].Name = "Pattern";
            dataGridViewDetail.Columns[1].Name = "RGB";
            dataGridViewDetail.Columns[2].Name = "Shiftx";
            dataGridViewDetail.Columns[3].Name = "Shifty";
        }

        private void dataGridViewDetail_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value != null && e.Value.ToString() == "-999")
            {
                e.CellStyle.ForeColor = Color.Red;
            }
            else
            { 
                e.CellStyle.ForeColor = dataGridViewDetail.DefaultCellStyle.ForeColor;
            }
        }

        AutoResetEvent[] VisionToolEventList;
        const int VisionTools = 5;
        CogJob CogJob { get; set; }
        CogToolCollection CogTools { get; set; }

        CogJob[] CogJobList { get; set; }
        CogToolCollection[] CogToolList { get; set; }


        string vppname = "DecapJob7_.vpp";
        private void FormMain_Load(object sender, EventArgs e)
        {
            string vpppath = @"D:\維智\cognex\0828\bin2\Debug\DecapJob7_.vpp";
            //string vpppath = @"..\TESTJob.vpp";

            VisionToolEventList = new AutoResetEvent[VisionTools];
            CogToolList = new CogToolCollection[VisionTools];
            CogJobList = new CogJob[VisionTools];
            for (int i = 0; i < VisionTools; i++)
            {

                CogJob job = VisionTool.Method.LoadVisionTool<CogJob>(vpppath);

                if (job != null)
                {
                    CogJobList[i] = job;
                    VisionToolEventList[i] = new AutoResetEvent(true);
                    CogToolList[i] = (job.VisionTool as CogToolGroup).Tools;
                }
                else
                {
                    MessageBox.Show("fail load vpp");
                    Environment.Exit(0);
                }
            }

            //
            CogJob = CogJobList[0];
            CogTools = CogToolList[0];


            /*
            CogJob job = VisionTool.Method.LoadVisionTool<CogJob>(vpppath);

            if (job != null)
            {
                CogJob = job;
                CogTools = (job.VisionTool as CogToolGroup).Tools;
            }
            else
            {
                MessageBox.Show("fail load vpp");
                Environment.Exit(0);
            }
            */

            //CogToolCollection Tools = (job.VisionTool as CogToolGroup).Tools;
            //var tool = Tools["CogImageConvertTool1"];

            // CogBlobTool blob = new CogBlobTool();
            // Tools.Add(blob);

            // string vppsavepath = @"..\DecapJob_.vpp";
            //VisionTool.Method.SaveVisionTool<CogJob>(job, vppsavepath);
        }

        string filepath;
        string[] filepaths;

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            dataGridViewDetail.Rows.Clear();
            // Load Image button
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Multiselect = true;
            dialog.Title = "請選擇檔案";
            dialog.Filter = "所有檔案(*.*)|*.*";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                string filename = dialog.FileName;
                filename = dialog.FileNames[0];
                filepaths = dialog.FileNames;

                foreach (string fileName in dialog.FileNames)
                {
                    string filePath = System.IO.Path.GetFullPath(fileName);
                    string fileNameOnly = System.IO.Path.GetFileName(fileName);

                    // 將檔案名稱和路徑加入到 DataGridView 中
                    dataGridView1.Rows.Add(fileNameOnly, filePath);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // button 2 
            var tool = CogTools["CogPMAlignTool1"];
            //(tool as CogPMAlignTool).InputImage = null;
            VisionTool.FormPMAlign f = new VisionTool.FormPMAlign((CogPMAlignTool)tool);
            tool.Changed += Tool_Changed;

            f.ShowDialog();
            f.Dispose();
        }

        private void Tool_Changed(object sender, CogChangedEventArgs e)
        {
            Console.WriteLine("sdf");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // button 4
            var tool = CogTools["CogPMAlignTool2"] as CogPMAlignTool;

            //var convert = CogTools["CogImageConvertTool1"] as CogImageConvertTool;

            //tool.InputImage = convert.OutputImage;


            VisionTool.FormPMAlign f = new VisionTool.FormPMAlign((CogPMAlignTool)tool);
            f.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // button 5
            var tool = CogTools["CogBlobTool1"];
            VisionTool.FormBlob f = new VisionTool.FormBlob((CogBlobTool)tool);
            f.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //Save vpp button
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Title = "Save Vpp";
            saveFileDialog.Filter = "vpp(*.vpp*)|*.vpp*";
  
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string vppsavepath = saveFileDialog.FileName;

                if (!vppsavepath.EndsWith(".vpp"))
                {
                    vppsavepath += ".vpp";
                
                }

                VisionTool.Method.SaveVisionTool<CogJob>(CogJob, vppsavepath);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            (sender as Control).BackColor = Color.Yellow;

            OpenFileDialog vppDialog = new OpenFileDialog();
            vppDialog.Multiselect =false;
            vppDialog.Title = "請選擇檔案";
            vppDialog.Filter = "vpp(*.vpp*)|*.vpp*";

            if (vppDialog.ShowDialog()==System.Windows.Forms.DialogResult.OK) 
            {
                string vpppath = vppDialog.FileName;
                Console.WriteLine(vpppath);

                for (int i = 0; i < VisionTools; i++)
                {

                    CogJob job = VisionTool.Method.LoadVisionTool<CogJob>(vpppath);

                    if (job != null)
                    {
                        CogJobList[i] = job;
                        VisionToolEventList[i] = new AutoResetEvent(true);
                        CogToolList[i] = (job.VisionTool as CogToolGroup).Tools;
                    }
                    else
                    {
                        MessageBox.Show("fail load vpp");
                        Environment.Exit(0);
                    }
                }

            }
            CogJob = CogJobList[0];
            CogTools = CogToolList[0];


            (sender as Control).BackColor = DefaultBackColor;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void button3_Click(object sender, EventArgs e)
        {
            shiftcsv = @"..\ShiftResult_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".csv";
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            // RUN button
            (sender as Control).BackColor = Color.Yellow;
            (sender as Control).Enabled = false;

            List<(string, Bitmap)> images = new List<(string, Bitmap)>();

            int counts = 200;

            for (int i = 0; i < filepaths.Count(); i += counts)
            {
                var subfilepaths = filepaths.Skip(i).Take(counts);
                foreach (var str in subfilepaths)
                {
                    images.Add((str, (Bitmap)Bitmap.FromFile(str)));
                }
                var vv = await RunProcess(images.ToArray());

                if (vv.Item1)
                {
                    foreach (var rr in vv.Item2)
                    {
                        Result result = rr;
                        int rgbIndex = 0; // 初始化RGB索引
                        foreach (var pad in result.ResultData.Keys)
                        {
                            foreach (var shiftxy in result.ResultData[pad])
                            {
                                // 获取当前RGB顺序
                                string currentRgb = GetRgbOrder(rgbIndex);
                                string str = rr.filename + "," + pad.ToString() + "," + currentRgb + "," + shiftxy.Item1 + "," + shiftxy.Item2+","+shiftxy.Item3 + "," + shiftxy.Item4 + "," + shiftxy.Item5 + "," + shiftxy.Item6 + ",";
                                DataResult.Add(str);
                            }
                        }
                    }
                }
            }


            (sender as Control).BackColor = DefaultBackColor;
            (sender as Control).Enabled = true;
            stopwatch.Stop();
            TimeSpan timespan = stopwatch.Elapsed;
            string elapsedTime = string.Format("{0:00}:{1:00}:{2:00}.{3:000}", timespan.Hours, timespan.Minutes, timespan.Seconds, timespan.Milliseconds);
            label1.Text = elapsedTime;
            using (StreamWriter sw = new StreamWriter(shiftcsv))
            {
                sw.WriteLine("filename,pattern,shiftx,sfifty");
                foreach (var line in DataResult)
                {
                    sw.WriteLine(line);
                }
            }
        }

        // 返回"R", "G", "B"基于当前的循环顺序
        public string GetRgbOrder(int index)
        {
            string[] order = { "B", "G", "R" };
            return order[index % 3];
        }

        class Result
        {
            public bool Success;
            public string filename;
            public int failstep;

            public int padCount;
            public int ledCount;
            public Dictionary<int, List<(double, double, double, double, double, double)>> ResultData = new Dictionary<int, List<(double, double, double, double, double, double)>>();
        }

        TaskCompletionSource<bool>[] JobStop = new TaskCompletionSource<bool>[100];
        async Task<(bool, Result[])> RunProcess((string, Bitmap)[] ImageData, int VisionToolIndex = 0)
        {
            JobStop[VisionToolIndex] = new TaskCompletionSource<bool>();

            return await Task.Run(() =>
            {

                List<Result> ResultList = new List<Result>();
                foreach (var data in ImageData)
                {
                    if (!JobStop[VisionToolIndex].Task.Wait(0))
                    {
                        Stopwatch stopwatch = Stopwatch.StartNew();

                        //File.AppendAllText(logFilePath, data.Item1 + Environment.NewLine);
                        //CogImage8Grey colorimage = new CogImage8Grey(data.Item2);


                        //CogImage24PlanarColor colorimage = new CogImage24PlanarColor(data.Item2);
                        //var convert = CogToolList[VisionToolIndex]["CogImageConvertTool1"] as CogImageConvertTool;
                        //convert.InputImage = colorimage;
                        //convert.Run();

                       

                        //CogImage8Grey grayimage = (CogImage8Grey)convert.OutputImage;
                        CogImage8Grey grayimage = new CogImage8Grey(data.Item2);

                        var v = DoProcess(grayimage, VisionToolIndex);

                        Result result = new Result()
                        {
                            filename = data.Item1,

                            Success = v.Item1,
                            failstep = v.Item2,
                            padCount = v.Item3,
                            ResultData = v.Item4
                        };
                        ResultList.Add(result);

                        if (!v.Item1)
                        {
                            Console.WriteLine("fail image=>" + data.Item1);
                        }


                        //grayimage.Dispose();
                        stopwatch.Stop();

                        GC.Collect();
                        Console.WriteLine("time:" + stopwatch.Elapsed.TotalSeconds.ToString());
                    }
                    else
                    {
                        return (false, ResultList.ToArray());
                    }


                }

                return (true, ResultList.ToArray());

            });
            //return (true, ResultList.ToArray());
        }


        //static int GetQuadrant(CogPMAlignResult result, double centerX, double centerY)
        //{
        //    var pose = result.GetPose();
        //    if (pose.TranslationX <= centerX && pose.TranslationY <= centerY) return 1; // 左下角
        //    if (pose.TranslationX > centerX && pose.TranslationY <= centerY) return 2;  // 右下角
        //    if (pose.TranslationX <= centerX && pose.TranslationY > centerY) return 3;  // 左上角
        //    if (pose.TranslationX > centerX && pose.TranslationY > centerY) return 4;   // 右上角
        //    return 0;
        //}
        //

        List<(double, double)> RGBShiftList = new List<(double, double)>()
        {(40,128),
            (40, 482),
            (40, 826) };
        /// <summary>
        /// 
        /// </summary>
        /// <param name="image"></param>
        /// <param name="visionToolIndex"></param>
        /// <returns></returns>
        /// 
        (bool, int, int, Dictionary<int, List<(double, double, double, double, double, double)>>) DoProcess(CogImage8Grey image, int visionToolIndex = 0)
        {

            var CogTools = CogToolList[visionToolIndex];


            var pm1 = CogTools["CogPMAlignTool1"] as CogPMAlignTool;
            var pm2 = CogTools["CogPMAlignTool2"] as CogPMAlignTool;
            var blob = CogTools["CogBlobTool1"] as CogBlobTool;

            Dictionary<int, List<(double, double, double, double, double, double)>> shiftresult = new Dictionary<int, List<(double, double, double, double, double, double)>>()
//            {
//                { 0,new List<(double, double, double, double, double, double)>(){ (-998,-998, -998, -998, -998, -998), (-998, -998, -998, -998, -998, -998), (-998, -998, -998, -998, -998, -998) } },
//            { 1,new List<(double, double, double, double, double, double)>(){ (-998,-998, -998, -998, -998, -998), (-998, -998, -998, -998, -998, -998), (-998, -998, -998, -998, -998, -998) } },
//{ 2,new List<(double, double, double, double, double, double)>(){ (-998,-998, -998, -998, -998, -998), (-998, -998, -998, -998, -998, -998), (-998, -998, -998, -998, -998, -998) } }

//            }
            ;

            int padcount = 0;
            //int allLedCount = 0;
            int[] ledcount = new int[4];
            

            //Step 0
            pm1.InputImage = image;
            pm1.Run();
            if (pm1.RunStatus.Result != CogToolResultConstants.Accept)
                return (false, CogTools.IndexOf(pm1), padcount, shiftresult);

            var results = pm1.Results;
            padcount = results.Count;
            if (results.Count <= 0 || results.Count < 4)
            {      
                
                return (false, CogTools.IndexOf(pm1), padcount, shiftresult);
            }


            List<CogPMAlignResult> pattern_list = new List<CogPMAlignResult>();
            foreach (CogPMAlignResult result in results)
                pattern_list.Add(result);
            /*
            // 获取画面中心的坐标
            double centerX = (pattern_list.Max(r => r.GetPose().TranslationX) + pattern_list.Min(r => r.GetPose().TranslationX)) / 2;
            double centerY = (pattern_list.Max(r => r.GetPose().TranslationY) + pattern_list.Min(r => r.GetPose().TranslationY)) / 2;

            // 根据每个坐标相对于中心的象限对其进行排序
            var sortedList = pattern_list.OrderBy(r => GetQuadrant(r, centerX, centerY)).ToList();

            foreach (var item in sortedList)
            {
                Console.WriteLine(item.GetPose().TranslationX + ", " + item.GetPose().TranslationY);
            }
            */

            //sort 1 2 3 4 
            var list0 = pattern_list.OrderByDescending(s => s.GetPose().TranslationY);
            var ResultList = list0.Take(2).OrderBy(s => s.GetPose().TranslationX).Concat(
                list0.Skip(2).Take(2).OrderBy(s => s.GetPose().TranslationX)
                );


            int padIndex = 0;
            

            //Step 1 find pattern
            foreach (CogPMAlignResult result in ResultList)
            {
                //var AnalysisTool = CogTools["CogResultsAnalysisTool1"] as CogResultsAnalysisTool;
                //(AnalysisTool.RunParams["TransX"] as CogResultsAnalysisInputExpression).Value = result.GetPose().TranslationX;
                //(AnalysisTool.RunParams["TransY"] as CogResultsAnalysisInputExpression).Value = result.GetPose().TranslationY;


                //(AnalysisTool.RunParams["X"] as CogResultsAnalysisInputExpression).Value = results.GetTrainArea().X;
                //(AnalysisTool.RunParams["Y"] as CogResultsAnalysisInputExpression).Value = results.GetTrainArea().Y;

                //
                if(padIndex >=4)
                    break;
                shiftresult[++padIndex] = new List<(double, double, double, double, double, double)>();


                var score = result.Score;
                var x = result.GetPose().TranslationX;
                var y = result.GetPose().TranslationY;
                var tx = results.GetTrainArea().X;
                var ty = results.GetTrainArea().Y;

                var rx = x + tx;
                var ry = y + ty;

                foreach (var c in RGBShiftList)
                {
                    //
                    pm2.SearchRegion = new CogRectangle()
                    {
                        X = rx + c.Item1,
                        Y = ry + c.Item2,
                        Height = pm2.Pattern.TrainRegion.EnclosingRectangle(CogCopyShapeConstants.All).Height * 1.2,
                        Width = pm2.Pattern.TrainRegion.EnclosingRectangle(CogCopyShapeConstants.All).Width * 1.5
                    };
                    pm2.InputImage = image;


                    pm2.Run();

                    if (pm2.RunStatus.Result != CogToolResultConstants.Accept)
                        return (false, CogTools.IndexOf(pm2), padcount, shiftresult);




                    //no rgb pad
                    if (pm2.Results.Count <= 0)
                    {
                        //File.AppendAllText(logFilePath, "results2 lost" + Environment.NewLine);
                        //return (false, CogTools.IndexOf(pm2), padcount, null);
                        shiftresult[padIndex].Add((-999, -999, -999, -999, -999,-999));

                    }
                    else
                    {
                        var xx = pm2.Results[0].GetPose().TranslationX;
                        var yy = pm2.Results[0].GetPose().TranslationY;

                        //
                        blob.InputImage = image;
                        blob.Region = new CogRectangle()
                        {
                            X = rx + c.Item1,
                            Y = ry + c.Item2,
                            Height = pm2.Pattern.TrainRegion.EnclosingRectangle(CogCopyShapeConstants.All).Height,
                            Width = pm2.Pattern.TrainRegion.EnclosingRectangle(CogCopyShapeConstants.All).Width
                        };


                        blob.Run();

                        if (blob.RunStatus.Result != CogToolResultConstants.Accept)
                        {
                            shiftresult[padIndex].Add((-999, -999,-999,-999,-999,-999));
                            continue; // return (false, CogTools.IndexOf(blob));
                        }

                        var blobresuts = blob.Results;
                        if (blobresuts.GetBlobs().Count <= 0)
                        {
                            shiftresult[padIndex].Add((-999, -999, -999, -999, -999, -999));
                            continue; // return (false, CogTools.IndexOf(blob));
                        }

                        var blobresult = blobresuts.GetBlobs()[0];

                        var MassX = blobresult.CenterOfMassX;
                        var MassY = blobresult.CenterOfMassY;

                        var shiftX = MassX - xx;
                        var shiftY = yy - MassY;

                        Console.WriteLine(shiftX.ToString() + " " + shiftY.ToString());

                        shiftresult[padIndex].Add((shiftX, shiftY, xx, yy, MassX, MassY));
                    }
                }
            }



            //
            return (true, -1, padcount, shiftresult);



        }

        private void button8_Click(object sender, EventArgs e)
        {
            JobStop[0]?.SetResult(true);
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }



        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                // 清除所有舊的圖形標記
                cogDisplay1.InteractiveGraphics.Clear();
                dataGridViewDetail.Rows.Clear();
                // 獲取選中行的檔案路徑
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                string filePath = row.Cells[1].Value.ToString();
                //讀取DataContect
                var points = dataList.Where(entry => entry.FileName == filePath).ToList();

                // 顯示圖片
                Bitmap bmp = new Bitmap(Image.FromFile(filePath));
                Cognex.VisionPro.CogImage24PlanarColor image = new Cognex.VisionPro.CogImage24PlanarColor((Bitmap)bmp);
                cogDisplay1.AutoFit = true;
                cogDisplay1.Image = image;
                txtFilename.Text = filePath;

                foreach (var point in points)
                {
                    double c = point.Shiftx;

                    if (c != -999)
                    {
                        double width1 = 530;
                        double heigth1 = 320;
                        double width2 = 95;
                        double heigth2 = 175;

                        //Pattern 方形
                        CogRectangle PnSquare = new CogRectangle();
                        PnSquare.X = point.Pnx - width1 / 2;
                        PnSquare.Y = point.Pny - heigth1 / 2;
                        PnSquare.Width = width1;
                        PnSquare.Height = heigth1;
                        PnSquare.LineWidthInScreenPixels = 10;
                        PnSquare.Interactive = true;
                        PnSquare.Color = CogColorConstants.Red;
                        cogDisplay1.InteractiveGraphics.Add(PnSquare, "", false);


                        //LED 方形
                        CogRectangle LedSquare = new CogRectangle();
                        LedSquare.X = point.Ledx - width2 / 2;
                        LedSquare.Y = point.Ledy - heigth2 / 2;
                        LedSquare.Width = width2;
                        LedSquare.Height = heigth2;
                        LedSquare.Color = CogColorConstants.Blue;
                        cogDisplay1.InteractiveGraphics.Add(LedSquare, "", false);

                        // Pattern 十字
                        CogPointMarker PnCrossPoint = new CogPointMarker();
                        PnCrossPoint.X = point.Pnx;
                        PnCrossPoint.Y = point.Pny;
                        PnCrossPoint.Color = CogColorConstants.Red;
                        PnCrossPoint.LineStyle = CogGraphicLineStyleConstants.Solid;
                        PnCrossPoint.SizeInScreenPixels = 20;
                        cogDisplay1.InteractiveGraphics.Add(PnCrossPoint, "", false);

                        // LED 十字
                        CogPointMarker LedCrossPoint = new CogPointMarker();
                        LedCrossPoint.X = point.Ledx;
                        LedCrossPoint.Y = point.Ledy;
                        LedCrossPoint.Color = CogColorConstants.Blue;
                        LedCrossPoint.LineStyle = CogGraphicLineStyleConstants.Solid;
                        LedCrossPoint.SizeInScreenPixels = 20;
                        cogDisplay1.InteractiveGraphics.Add(LedCrossPoint, "", false);
                        double PxSize = double.Parse(txtPxSize.Text);
                        double Shiftx2um = point.Shiftx * PxSize;
                        double Shifty2um = point.Shifty * PxSize;
                        // 將篩選後的列表綁定到第二個 GridView
                        dataGridViewDetail.Rows.Add(point.Pattern, point.RGB, Shiftx2um, Shifty2um);
                    }
                    else
                    {
                        dataGridViewDetail.Rows.Add(point.Pattern, point.RGB, point.Shiftx, point.Shifty);

                    }
                }
            }
        }

        private void dataGridViewDetail_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                if (lastRectangleID != null)
                {
                    cogDisplay1.InteractiveGraphics.Remove(lastRectangleID);
                    lastRectangleID = null;
                }

                string pattern = dataGridViewDetail.Rows[e.RowIndex].Cells["Pattern"].Value.ToString();
                string rgb = dataGridViewDetail.Rows[e.RowIndex].Cells["RGB"].Value.ToString();
                var pointCC = dataList.FirstOrDefault(d => d.FileName == txtFilename.Text && d.Pattern == pattern && d.RGB == rgb);
                double c = pointCC.Shiftx;

                if (c != -999) 
                {
                    double pnxCC = pointCC.Pnx;
                    double pnyCC = pointCC.Pny;
                    double width1 = 530;
                    double heigth1 = 320;

                    CogRectangle PnxSquare = new CogRectangle();
                    PnxSquare.X = pnxCC - width1 / 2;
                    PnxSquare.Y = pnyCC - heigth1 / 2;
                    PnxSquare.Width = width1;
                    PnxSquare.Height = heigth1;
                    PnxSquare.Color = CogColorConstants.Green;
                    PnxSquare.LineWidthInScreenPixels = 2;
                    lastRectangleID = "retangle_" + Guid.NewGuid().ToString();
                    cogDisplay1.InteractiveGraphics.Add(PnxSquare, lastRectangleID, false);
                }
            }



        }




        /// <summary>
        /// MultiTool
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void button9_Click(object sender, EventArgs e)
        {
            cogDisplay1.InteractiveGraphics.Clear();
            dataList.Clear();
            string csv = @"..\ShiftResult_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".csv";
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            // RUN button
            (sender as Control).BackColor = Color.Yellow;
            (sender as Control).Enabled = false;

            List<(string, Bitmap)> images = new List<(string, Bitmap)>();



            BlockingCollection<string> ResultLedList = new BlockingCollection<string>();
            BlockingCollection<Result> ResultDataList = new BlockingCollection<Result>();

            lbTotal.Text = filepaths.Length.ToString();

            int PadCount = 0;
            int ImageCount = 0;
            int LedCount = 0;
            //TaskCompletionSource<bool> stop = new TaskCompletionSource<bool>();
            Task ProcessImageTask = null;



            ProcessImageTask = Task.Run(() =>
            {
                Parallel.ForEach(filepaths, new ParallelOptions { MaxDegreeOfParallelism = Environment.ProcessorCount - 1 },              
                tt =>
                {
                    //Console.WriteLine(tt.ToString());
                    while (true)
                    {
                        int v = WaitHandle.WaitAny(VisionToolEventList, 10);
                        if (v != WaitHandle.WaitTimeout)
                        {
                            Bitmap img = null;
                            try
                            {
                                img = (Bitmap)Bitmap.FromFile(tt);
                                (string, Bitmap) data = (tt, img);   // (tt,(Bitmap)Bitmap.FromFile(tt));
                               
                                var vv = RunProcess(new (string, Bitmap)[] { data }, v).Result;

                                if (vv.Item1)
                                {

                                    foreach (var rr in vv.Item2)
                                    {
                                        Result result = rr;
                                        Interlocked.Add(ref PadCount, result.padCount);
                                        ResultDataList.Add(result);
                                        int rgbIndex = 0; // 初始化RGB索引

                                        if (result.ResultData != null)
                                        {
                                            foreach (var pad in result.ResultData.Keys)
                                            {
                                                foreach (var shiftxy in result.ResultData[pad])
                                                {
                                                    if (shiftxy.Item1 != -999 && shiftxy.Item1 != -998)
                                                        Interlocked.Increment(ref LedCount);

                                                    string currentRgb = GetRgbOrder(rgbIndex);

                                                    double shiftx = shiftxy.Item1 ;
                                                    double sfifty = shiftxy.Item2 ;
                                                    double pn_x = shiftxy.Item3  ;
                                                    double pn_y = shiftxy.Item4  ;
                                                    double led_x = shiftxy.Item5 ;
                                                    double led_y = shiftxy.Item6 ;
                                                    string str = rr.filename + "," + pad.ToString() + "," + currentRgb + "," + shiftx + "," + sfifty + "," + pn_x + "," + pn_y + "," + led_x + "," + led_y;
                                                    Console.WriteLine(str);
                                                    ResultLedList.Add(str);

                                                    string[] parts = str.ToString().Split(',');

                                                    var dataContent = new DataContent(
                                                        parts[0], // FileName
                                                        parts[1], // Pattern
                                                        parts[2], // RGB
                                                        double.Parse(parts[3]), // Shiftx
                                                        double.Parse(parts[4]), // Shifty
                                                        double.Parse(parts[5]), // Pnx
                                                        double.Parse(parts[6]), // Pny
                                                        double.Parse(parts[7]), // Ledx
                                                        double.Parse(parts[8])  // Ledy
                                                        );

                                                    dataList.Add(dataContent);
                                                    //MultiplyValuesAndSaveToCsv();
                                                    rgbIndex++; // 更新RGB索引
                                                }
                                            }
                                        }


                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.ToString());
                                Console.WriteLine(ex.ToString());
                            }
                            finally
                            {
                                img.Dispose();
                                GC.Collect();
                                Interlocked.Increment(ref ImageCount);
                                VisionToolEventList[v].Set();
                            }

                            //Console.WriteLine(tt.ToString());

                            break;
                        }
                    }

                    //Console.WriteLine(tt.ToString());
                });


            });

            //
            var dddddd = Task.Run(() =>
            {
                while (!ProcessImageTask.Wait(100))
                {
                    this.Invoke(new Action(() =>
                    {
                        lbDeal.Text = 
                        ImageCount.ToString("000000") + "/" +
                        PadCount.ToString("000000") + "/" +
                        ResultLedList.Count.ToString("000000") + "/" +
                        LedCount.ToString("000000")
                        ;

                        label3.Text = stopwatch.Elapsed.TotalSeconds.ToString("0.00000") + " s";

                    }));

                }

            });


            await ProcessImageTask;
            await dddddd;

            DataResult.Clear();
            DataResult.AddRange(ResultLedList);

            stopwatch.Stop();
            TimeSpan timespan = stopwatch.Elapsed;
            string elapsedTime = string.Format("{0:00}:{1:00}:{2:00}.{3:000}", timespan.Hours, timespan.Minutes, timespan.Seconds, timespan.Milliseconds);
            label1.Text = elapsedTime;
            using (StreamWriter sw = new StreamWriter(csv))
            {
                double PxSize = double.Parse(txtPxSize.Text);
                sw.WriteLine("FileName,Pattern,RGB,Shiftx,Shifty,Pnx,Pny,Ledx,Ledy");
                // 乘法操作
                foreach (var data in dataList)
                {
                    double t = data.Shiftx ;
                    if (t == -999)
                    {
                        sw.WriteLine($"{data.FileName},{data.Pattern},{data.RGB},{-999},{-999},{-999},{-999},{-999},{-999}");
                    }
                    else
                    {
                        double Shiftx2um = data.Shiftx * PxSize;
                        double Shifty2um = data.Shifty * PxSize;
                        double Pnx2um = data.Pnx * PxSize;
                        double Pny2um = data.Pny * PxSize;
                        double Ledx2um = data.Ledx * PxSize;
                        double Ley2um = data.Ledy * PxSize;
                        sw.WriteLine($"{data.FileName},{data.Pattern},{data.RGB},{Shiftx2um},{Shifty2um},{Pnx2um},{Pny2um},{Ledx2um},{Ley2um}");
                    }
                }
            }

            csv = @"..\PadResult_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".csv";
            using (StreamWriter sw = new StreamWriter(csv))
            {
                sw.WriteLine("filename,success,padcount");
                foreach (var r in ResultDataList)
                {
                    string str = string.Empty;
                    List<(double, double)> dsf = new List<(double, double)>();

                    if (r.ResultData != null)
                    {
                        foreach (var a in r.ResultData.Values)
                            str += ("," + a.Count.ToString());
                    }
                    sw.WriteLine(r.filename + "," + (r.Success ? "1" : "0") + "," + r.padCount.ToString()+str);
                }
            }

            //await Task.Delay(2000);
            //stop.SetResult(true);

            lbDeal.Text = ImageCount.ToString("000000") + "/" +
                        PadCount.ToString("000000") + "/" +
                        ResultLedList.Count.ToString("000000") + "/" +
                        LedCount.ToString("0000000");

            (sender as Control).BackColor = DefaultBackColor;
            (sender as Control).Enabled = true;


            Console.WriteLine("Result:" + ImageCount.ToString("0000") + "/" +
                PadCount.ToString("000000") + "/" +
                        ResultLedList.Count.ToString("0000"));

            string msg = "Result:" + ImageCount.ToString("0000") + "/" +
                PadCount.ToString("000000") + "/" +
                        ResultLedList.Count.ToString("0000") + "/" +
                        LedCount.ToString("0000000")
                        ;
            MessageBox.Show(msg);
        }

        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(0);
        }

        private void btnSaveImage_Click(object sender, EventArgs e)
        {
           SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Title = "Save image";
            saveFileDialog.Filter = "所有檔案(*.*)|*.*";
            saveFileDialog.FileName ="shiftdata_"+Path.GetFileName(txtFilename.Text);

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                Cognex.VisionPro.ICogImage cogImage = cogDisplay1.Image;

                if (cogImage != null)
                {
                    Image image = default(Image);
                    //image = cogDisplay1.CreateContentBitmap(Cognex.VisionPro.Display.CogDisplayContentBitmapConstants.Image,null,0);


                    image = cogDisplay1.CreateContentBitmap(Cognex.VisionPro.Display.CogDisplayContentBitmapConstants.Custom,
                        new CogRectangle()
                        {
                            X = 0,
                            Y = 0,
                            Width = 5120,
                            Height = 5120
                        }, 0);

                    image.Save(saveFileDialog.FileName);
                    pictureBox1.Image = image;
                }
                else 
                {
                    MessageBox.Show("no image to save");
                }
            
            }
        }

        private void cogDisplay1_Enter(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btnCogImageConvertTool_Click(object sender, EventArgs e)
        {
            //var tool = CogTools[" CogImageConvertTool1"];
            //var tool = CogTools["CogPMAlignTool1"];
            //(tool as CogPMAlignTool).InputImage = null;
            //VisionTool.Form f = new VisionTool.FormPMAlign((CogPMAlignTool)tool);
            //tool.Changed += Tool_Changed;

            //f.ShowDialog();
            //f.Dispose();
        }

        private void dataGridViewDetail_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
