﻿namespace VisionTool
{
    partial class FormConvert
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cogImageConvertEdit1 = new Cognex.VisionPro.ImageProcessing.CogImageConvertEdit();
            this.SuspendLayout();
            // 
            // cogImageConvertEdit1
            // 
            this.cogImageConvertEdit1.Location = new System.Drawing.Point(-3, 0);
            this.cogImageConvertEdit1.Name = "cogImageConvertEdit1";
            this.cogImageConvertEdit1.Size = new System.Drawing.Size(1081, 640);
            this.cogImageConvertEdit1.TabIndex = 0;
            this.cogImageConvertEdit1.ToolSyncObject = null;
            // 
            // FormConvert
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1077, 643);
            this.Controls.Add(this.cogImageConvertEdit1);
            this.Name = "FormConvert";
            this.Text = "Form2";
            this.ResumeLayout(false);

        }

        #endregion

        private Cognex.VisionPro.ImageProcessing.CogImageConvertEdit cogImageConvertEdit1;
    }
}