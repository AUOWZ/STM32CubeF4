﻿using Cognex.VisionPro.ImageProcessing;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VisionTool
{
    public partial class FormConvert : Form
    {
        public FormConvert(CogImageConvertTool tool)
        {
            InitializeComponent();
            cogImageConvertEdit1.Subject = tool;
        }

        private void FormConvert_Load(object sender, EventArgs e)
        {

        }
    }
}
