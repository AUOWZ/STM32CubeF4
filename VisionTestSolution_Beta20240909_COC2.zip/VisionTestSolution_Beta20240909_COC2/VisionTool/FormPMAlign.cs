﻿using Cognex.VisionPro.Blob;
using Cognex.VisionPro.PMAlign;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VisionTool
{
    public partial class FormPMAlign : Form
    {
        public FormPMAlign(CogPMAlignTool tool)
        {
            InitializeComponent();

            cogPMAlignEditV21.Subject = tool;
        }

        private void FormBlob_Load(object sender, EventArgs e)
        {
            //cogBlobEditV21.Subject = 
        }
    }
}
