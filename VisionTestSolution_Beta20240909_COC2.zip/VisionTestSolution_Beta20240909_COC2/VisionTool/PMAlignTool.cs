﻿using Cognex.VisionPro;
using Cognex.VisionPro.PMAlign;
using System;

namespace VisionTool
{



    public abstract class ToolObject
    {
        public enum OperationResult
        {
            success,
        }
        public abstract OperationResult LoadTool(string path);
       
    }


    internal class PMAlignTool: ToolObject
    {

        private CogPMAlignTool _Tool;

        public CogPMAlignTool Tool { get { return _Tool; } set { _Tool = value; } }


        public PMAlignTool()
        {
            _Tool = new CogPMAlignTool();

        }

        public bool Load(string path )
        {
            var obj = CogSerializer.LoadObjectFromFile(path);

            if(obj != null)
                _Tool = (CogPMAlignTool)obj;

            return obj != null;
        }


        public bool Save(string path ) 
        {
            try
            {
                CogSerializer.SaveObjectToFile(_Tool, path);
            }
            catch 
            {
                return false;
            }


            return true;
        }

        public override OperationResult LoadTool(string path)
        {
            throw new NotImplementedException();
        }
    }
}
