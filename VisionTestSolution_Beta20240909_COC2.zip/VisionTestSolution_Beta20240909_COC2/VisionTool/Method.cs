﻿using Cognex.VisionPro.Implementation;
using Cognex.VisionPro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VisionTool
{
    public static class Method
    {
        /// <summary>
        /// 加载取像工具
        /// </summary>
        /// <param name="VppFilePath"></param>
        /// <returns></returns>
        public static T LoadVisionTool<T>(string VppFilePath)
        {
            string mPath = VppFilePath;
            T _toolBase = default(T); //Activator.CreateInstance(typeof(T));    
            try
            {
                if (System.IO.File.Exists(mPath))
                {
                    _toolBase = (T)CogSerializer.LoadObjectFromFile(mPath);
                    //GC.Collect();
                }
                else
                {
                    _toolBase = (T)Activator.CreateInstance(typeof(T));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("加载取像工具文件失败:" + ex.Message);
            }
            return _toolBase;
        }


        public static void SaveVisionTool<T>(T fifoTool, string VppFilePath) //where T : CogToolBase
        {
            try
            {
                CogSerializer.SaveObjectToFile(fifoTool, VppFilePath,
                    typeof(BinaryFormatter), CogSerializationOptionsConstants.Minimum);
            }
            catch (Exception ex)
            {
                MessageBox.Show("取像工具保存失败：" + ex.Message);
            }
        }
    }
}
