﻿using Cognex.VisionPro.Blob;
using Cognex.VisionPro.Display;
using Cognex.VisionPro.PMAlign;
using Cognex.VisionPro;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cognex.VisionPro.ImageProcessing;
using Cognex.VisionPro.CalibFix;
using System.IO;

namespace VisionTool
{
    public class FitMark
    {


        //vision tool
        public CogBlobTool _CogBlobTool;
        public CogPMAlignTool _CogPMAlignTool;
        CogImageConvertTool _CogImageConvertTool = new CogImageConvertTool();
        CogFixtureTool _CogFixtureTool = new CogFixtureTool();

        public string VisionPath { get;  set ; } = CommonSetting.Common.VISION_PATH;

        public FitMark()
        {
            
            InitialVisionTool();
        }

        public void SetVisionPath(string path)
        {
            VisionPath = path;
        }



        public void InitialVisionTool()
        {


            string vpppath = VisionPath + "BlobTool.vpp";
            _CogBlobTool = Method.LoadVisionTool<CogBlobTool>(vpppath);

            //
            vpppath = VisionPath + "PMAlignTool.vpp";
            _CogPMAlignTool = Method.LoadVisionTool<CogPMAlignTool>(vpppath);

            
        }

        public async Task InitialVisionTool(bool delay = false)
        {
            await Task.Run(() =>
            {

                InitialVisionTool();

            });
            if (delay)
                await Task.Delay(3000);
            //

        }



       

        public async Task<(bool success, double MassX, double MassY, double Score)> VisionProcess(Bitmap image)
        {

            //CogImage8Grey grayimage = new CogImage8Grey(image);

            

            return await Task.Run(() =>
            {
                        
                CogImage8Grey grayimage = new CogImage8Grey(image);

                try
                {
                    //
                    _CogPMAlignTool.InputImage = grayimage;
                    _CogPMAlignTool.Run();
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                    image.Save(@"D:\error_"+ DateTime.Now.ToString(@"yyyyMMdd HHmmssfff") +".png");
                }
               


                if (_CogPMAlignTool.RunStatus.Result == CogToolResultConstants.Accept &&
                _CogPMAlignTool.Results.Count > 0)
                {

                    var result = _CogPMAlignTool.Results[0];
                    var pattern = _CogPMAlignTool.Pattern.TrainRegion as CogRectangle;
                    var tranX = result.GetPose().TranslationX;
                    var tranY = result.GetPose().TranslationY;
                    var rotate = result.GetPose().Rotation;
                    var score = result.Score;

                    return (true, tranX, tranY, score);

                    //
                    _CogFixtureTool.InputImage = grayimage;
                    _CogFixtureTool.RunParams.UnfixturedFromFixturedTransform = new CogTransform2DLinear() { TranslationX = tranX, TranslationY = tranY, Rotation = rotate };
                    _CogFixtureTool.Run();



                    //
                    _CogBlobTool.InputImage = _CogFixtureTool.OutputImage;
                    _CogBlobTool.Region = _CogPMAlignTool.Pattern.TrainRegion;               
                    _CogBlobTool.Run();

                    //
                    if (_CogBlobTool.RunStatus.Result == CogToolResultConstants.Accept &&
                     _CogBlobTool.Results.GetBlobs().Count > 0)
                    {
                        var blobdata = _CogBlobTool.Results.GetBlobs()[0];
                        double xxx = blobdata.CenterOfMassX + tranX;
                        double yyy = blobdata.CenterOfMassY + tranY;



                        //
                        return (true, xxx, yyy, score);
                    }




                }

                return (false, -1, -1, -1);

            });


        }
    }
}
